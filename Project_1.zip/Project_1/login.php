<?php 

// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: mmFront.php");
    exit;
}
 
// Include config file
require_once "config/database.php";
 
// Define variables and initialize with empty values
$email = $password = "";
$email_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["email"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["email"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT idUser, email, namaLengkap, password FROM user WHERE email = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $name, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $username;   
                            $_SESSION["name"] = $name; 
                            
                            // Redirect user to welcome page
                            header("location: home.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid email or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid email or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="login.css" />
    <title>Login - PoorBye</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon" />
    <link rel="stylesheet" href="css/login.css" />
  </head>
  <body>
    <!-- NAVBAR -->
    <!-- <nav class="navbar navbar-expand-lg bg-light"> -->
    <navbar class="navbar navbar-expand-lg" style="background-color: #f0fff3">
      <div class="container-fluid">
        <a class="navbar-brand align-items-center ms-4 mb-1" href="#">
          <img src="img/LOGO.png" alt="LOGO" width="70" height="70" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item ms-4 me-4">
              <a class="nav-link active" aria-current="page" style="color: #59606d; font-weight: bold; font-family: 'Poppins', sans-serif" href="#">COURSE</a>
            </li>
            <li class="nav-item ms-4 me-4">
              <a class="nav-link" style="color: #59606d; font-weight: bold; font-family: 'Poppins', sans-serif" href="#">STATISTICS</a>
            </li>
            <li class="nav-item ms-4 me-4">
              <a class="nav-link" style="color: #59606d; font-weight: bold; font-family: 'Poppins', sans-serif" href="#">MONEY MANAGEMENT</a>
            </li>
          </ul>
          <!-- <form class="d-flex" role="search">
                  <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                  <button class="btn btn-outline-success" type="submit">Search</button>
                </form> -->
          <ul class="navbar-nav align-items-center me-4">
            <li class="nav-item me-4">
              <a class="nav-link" style="color: #59606d; font-weight: bold; font-family: 'Poppins', sans-serif">Halo, [username]!</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" style="color: #59606d" align-items-center href="#">
                <svg width="70" height="70" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M106.996 99.72C112.741 92.8084 116.736 84.615 118.644 75.8327C120.552 67.0505 120.317 57.9378 117.959 49.2657C115.6 40.5935 111.188 32.6169 105.095 26.0107C99.0014 19.4045 91.4068 14.363 82.9531 11.3127C74.4994 8.26245 65.4354 7.29311 56.5279 8.48671C47.6203 9.68031 39.1313 13.0017 31.7789 18.17C24.4265 23.3383 18.427 30.2014 14.288 38.1787C10.149 46.156 7.99215 55.0128 8.00002 64C8.00304 77.0647 12.607 89.7111 21.004 99.72L20.924 99.788C21.204 100.124 21.524 100.412 21.812 100.744C22.172 101.156 22.56 101.544 22.932 101.944C24.052 103.16 25.204 104.328 26.412 105.424C26.78 105.76 27.16 106.072 27.532 106.392C28.812 107.496 30.128 108.544 31.492 109.52C31.668 109.64 31.828 109.796 32.004 109.92V109.872C41.3724 116.465 52.5484 120.003 64.004 120.003C75.4596 120.003 86.6356 116.465 96.004 109.872V109.92C96.18 109.796 96.336 109.64 96.516 109.52C97.876 108.54 99.196 107.496 100.476 106.392C100.848 106.072 101.228 105.756 101.596 105.424C102.804 104.324 103.956 103.16 105.076 101.944C105.448 101.544 105.832 101.156 106.196 100.744C106.48 100.412 106.804 100.124 107.084 99.784L106.996 99.72ZM64 32C67.5601 32 71.0402 33.0557 74.0003 35.0335C76.9604 37.0114 79.2675 39.8226 80.6299 43.1117C81.9922 46.4008 82.3487 50.02 81.6542 53.5116C80.9596 57.0033 79.2453 60.2106 76.7279 62.7279C74.2106 65.2453 71.0033 66.9596 67.5117 67.6541C64.02 68.3487 60.4008 67.9922 57.1117 66.6298C53.8227 65.2674 51.0114 62.9603 49.0336 60.0003C47.0557 57.0402 46 53.5601 46 50C46 45.2261 47.8964 40.6477 51.2721 37.2721C54.6478 33.8964 59.2261 32 64 32ZM32.028 99.72C32.0974 94.4679 34.2318 89.4542 37.9695 85.7637C41.7071 82.0733 46.7474 80.0027 52 80H76C81.2526 80.0027 86.293 82.0733 90.0306 85.7637C93.7682 89.4542 95.9026 94.4679 95.972 99.72C87.1994 107.625 75.8091 112 64 112C52.191 112 40.8007 107.625 32.028 99.72Z"
                    fill="#59606D"
                  />
                </svg>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </navbar>
    <!-- AKHIR NAVBAR -->

    <div class="batas">
      <div class="bagi31"></div>
      <div class="bagi32">
        <div class="boxluar">
          <div class="judul">LOG IN</div>
          <div class="pengantar">Gunakan akun Anda untuk <br> menggunakan fitur PoorBye<br>sepenuhnya</div>

          <form action="" method="post" id="form">
            <label class="label1" for="email">Email</label>
            <input type="text" name="email" id="email" />

            <label class="label2" for="email">Password</label>
            <input type="password" name="password" id="password" />

            <input type="submit" id="submit" value="MASUK">

          </form>

        </div>

        <div class="blmada">Belum memiliki akun? Silakan <a class="blmada1" href="signup.php">Sign Up</a></div>
      </div>
      <div class="bagi33"></div>
    </div>

    <!-- awal footer -->
    <div class="footerTop">
      <div class="explain">
        <div class="title">
          <h3>PoorBye</h3>
        </div>
        <p>Poorbye merupakan website untuk membantu generasi muda mengatur dan mengelola keuangan, guna mempersiapkan masa depannya</p>
      </div>
      <div class="menu">
        <div class="title">
          <h3>Menu</h3>
        </div>
        <p>COURSE</p>
        <p>STATISTIC</p>
        <p>MONEY MANAGEMENT</p>
        <p>PROFILE</p>
      </div>
      <div class="explain">
        <div class="title">
          <h3>Kontak</h3>
        </div>
        <div class="hub">
          <svg width="38" height="38" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M19.665 19.851C20.6045 19.851 21.409 19.5207 22.0786 18.8601C22.747 18.2007 23.0812 17.4076 23.0812 16.4808C23.0812 15.554 22.747 14.7603 22.0786 14.0997C21.409 13.4403 20.6045 13.1106 19.665 13.1106C18.7255 13.1106 17.9216 13.4403 17.2531 14.0997C16.5835 14.7603 16.2487 15.554 16.2487 16.4808C16.2487 17.4076 16.5835 18.2007 17.2531 18.8601C17.9216 19.5207 18.7255 19.851 19.665 19.851ZM19.665 36.07C19.4373 36.07 19.2095 36.0279 18.9818 35.9436C18.754 35.8594 18.5547 35.747 18.3839 35.6066C14.2275 31.9836 11.1244 28.6208 9.07463 25.5179C7.02488 22.414 6 19.5139 6 16.8178C6 12.605 7.3739 9.2489 10.1217 6.74934C12.8684 4.24978 16.0495 3 19.665 3C23.2805 3 26.4616 4.24978 29.2083 6.74934C31.9561 9.2489 33.33 12.605 33.33 16.8178C33.33 19.5139 32.3051 22.414 30.2554 25.5179C28.2056 28.6208 25.1025 31.9836 20.9461 35.6066C20.7753 35.747 20.576 35.8594 20.3482 35.9436C20.1205 36.0279 19.8927 36.07 19.665 36.07Z"
              fill="#59606D"
            />
          </svg>
          <p class="location">Sentul, Jawa Barat</p>
        </div>
        <div class="hub">
          <svg width="38" height="38" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M31.6825 24.3517C29.735 24.3517 27.8508 24.035 26.0933 23.465C25.818 23.3717 25.5219 23.3578 25.2391 23.425C24.9563 23.4922 24.6981 23.6378 24.4942 23.845L22.0083 26.9642C17.5275 24.8267 13.3317 20.7892 11.0992 16.15L14.1867 13.5217C14.6142 13.0783 14.7408 12.4608 14.5667 11.9067C13.9808 10.1492 13.68 8.265 13.68 6.3175C13.68 5.4625 12.9675 4.75 12.1125 4.75H6.63417C5.77917 4.75 4.75 5.13 4.75 6.3175C4.75 21.0267 16.9892 33.25 31.6825 33.25C32.8067 33.25 33.25 32.2525 33.25 31.3817V25.9192C33.25 25.0642 32.5375 24.3517 31.6825 24.3517Z"
              fill="#59606D"
            />
          </svg>
          <p class="location">+62 858-4767-1769</p>
        </div>
        <div class="hub">
          <svg width="38" height="38" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M19.0001 3.16699C23.302 3.16699 23.8387 3.18283 25.5266 3.26199C27.2128 3.34116 28.3607 3.60558 29.3709 3.99824C30.4159 4.40041 31.2962 4.94508 32.1766 5.82383C32.9817 6.61533 33.6047 7.57276 34.0022 8.62949C34.3932 9.63807 34.6592 10.7876 34.7384 12.4738C34.8128 14.1617 34.8334 14.6984 34.8334 19.0003C34.8334 23.3022 34.8176 23.839 34.7384 25.5268C34.6592 27.2131 34.3932 28.361 34.0022 29.3712C33.6058 30.4285 32.9827 31.3861 32.1766 32.1768C31.3849 32.9817 30.4275 33.6046 29.3709 34.0024C28.3623 34.3935 27.2128 34.6595 25.5266 34.7387C23.8387 34.8131 23.302 34.8337 19.0001 34.8337C14.6982 34.8337 14.1614 34.8178 12.4736 34.7387C10.7873 34.6595 9.63941 34.3935 8.62925 34.0024C7.5721 33.6057 6.6145 32.9827 5.82358 32.1768C5.01831 31.3855 4.39531 30.428 3.998 29.3712C3.60533 28.3626 3.34091 27.2131 3.26175 25.5268C3.18733 23.839 3.16675 23.3022 3.16675 19.0003C3.16675 14.6984 3.18258 14.1617 3.26175 12.4738C3.34091 10.786 3.60533 9.63966 3.998 8.62949C4.39421 7.57211 5.01735 6.61442 5.82358 5.82383C6.61473 5.01827 7.57226 4.39523 8.62925 3.99824C9.63941 3.60558 10.7857 3.34116 12.4736 3.26199C14.1614 3.18758 14.6982 3.16699 19.0001 3.16699ZM19.0001 11.0837C16.9004 11.0837 14.8868 11.9177 13.4022 13.4024C11.9175 14.8871 11.0834 16.9007 11.0834 19.0003C11.0834 21.1 11.9175 23.1136 13.4022 24.5983C14.8868 26.0829 16.9004 26.917 19.0001 26.917C21.0997 26.917 23.1133 26.0829 24.598 24.5983C26.0827 23.1136 26.9167 21.1 26.9167 19.0003C26.9167 16.9007 26.0827 14.8871 24.598 13.4024C23.1133 11.9177 21.0997 11.0837 19.0001 11.0837ZM29.2917 10.6878C29.2917 10.1629 29.0832 9.65951 28.7121 9.28834C28.3409 8.91718 27.8375 8.70866 27.3126 8.70866C26.7877 8.70866 26.2843 8.91718 25.9131 9.28834C25.5419 9.65951 25.3334 10.1629 25.3334 10.6878C25.3334 11.2127 25.5419 11.7161 25.9131 12.0873C26.2843 12.4585 26.7877 12.667 27.3126 12.667C27.8375 12.667 28.3409 12.4585 28.7121 12.0873C29.0832 11.7161 29.2917 11.2127 29.2917 10.6878ZM19.0001 14.2503C20.2599 14.2503 21.468 14.7508 22.3588 15.6416C23.2496 16.5324 23.7501 17.7405 23.7501 19.0003C23.7501 20.2601 23.2496 21.4683 22.3588 22.3591C21.468 23.2499 20.2599 23.7503 19.0001 23.7503C17.7403 23.7503 16.5321 23.2499 15.6413 22.3591C14.7505 21.4683 14.2501 20.2601 14.2501 19.0003C14.2501 17.7405 14.7505 16.5324 15.6413 15.6416C16.5321 14.7508 17.7403 14.2503 19.0001 14.2503Z"
              fill="#59606D"
            />
          </svg>
          <p class="location">PoorBye.id</p>
        </div>
        <div class="hub">
          <svg width="38" height="38" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M31.6667 12.6663L19.0001 20.583L6.33341 12.6663V9.49967L19.0001 17.4163L31.6667 9.49967M31.6667 6.33301H6.33341C4.57591 6.33301 3.16675 7.74217 3.16675 9.49967V28.4997C3.16675 29.3395 3.50038 30.145 4.09424 30.7388C4.68811 31.3327 5.49356 31.6663 6.33341 31.6663H31.6667C32.5066 31.6663 33.3121 31.3327 33.9059 30.7388C34.4998 30.145 34.8334 29.3395 34.8334 28.4997V9.49967C34.8334 8.65982 34.4998 7.85437 33.9059 7.2605C33.3121 6.66664 32.5066 6.33301 31.6667 6.33301V6.33301Z"
              fill="#59606D"
            />
          </svg>
          <p class="location">poorbye@gmail.com</p>
        </div>
      </div>
    </div>
    <div class="footerDown">
      <p>© 2022 PoorBye | All Rights Reserved</p>
    </div>
    <!-- akhir footer -->
  </body>
</html>