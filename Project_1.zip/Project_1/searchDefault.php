<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>

<?php

$idUser = $_SESSION["id"];


$allcourse_box = mysqli_fetch_all(mysqli_query($link, "SELECT *
from course"), MYSQLI_ASSOC);

// var_dump($allcourse_box);
$count = 0;

foreach($allcourse_box as $item) {
  $data_idCourse[$count] = $item['idCourse'];
  $data_namaCourse[$count] = $item['namaCourse'];
  $data_topicCount[$count] = $item['topicCount'];
  $data_rate[$count] = $item['rate'];
  $data_totalWaktu[$count] = $item['totalWaktu'];

  $count++;
  
}


//ENROLLED COURSE
 
$enrolledCourse = mysqli_fetch_all(mysqli_query($link, "SELECT *
from course c join enrollment e on c.idCourse = e.IdCourse
where e.IdUser = $idUser;"), MYSQLI_ASSOC);

// var_dump($enrolledCourse);
$enrolledCourse_count = count($enrolledCourse);

// FOR PROGRESS BAR
$progress = mysqli_fetch_all(mysqli_query($link, "SELECT
c.idCourse,
c.namaCourse,
c.topicCount,
count(t.idTopic)
FROM watchedtopic wt join topic t on wt.idTopic = t.idTopic
join course c on c.idCourse = t.idCourse
where idUser = $idUser
group by t.idCourse"), MYSQLI_ASSOC);
// var_dump($progress);

$count_p = 0;

$percentage[] = '';
$percentage_idCourse[] = '';
$percentage_namaCourse[] = '';
foreach($progress as $item) {
  $percentage[$count_p] = $item['count(t.idTopic)'] / $item['topicCount'];
  $percentage_idCourse[$count_p] = $item['idCourse'];
  $percentage_namaCourse[$count_p] = $item['namaCourse'];
  $count_p++;
}

// var_dump($percentage);
// var_dump($percentage_idCourse);
// var_dump($data_idCourse);

// echo $count_p;


$count = 0;

$data_enrolledCourseName[] = '';
$data_percentage[] = '';

// var_dump($data_idCourse);

// foreach($enrolledCourse as $item) {
//   $data_enrolledCourseName[$count] = $item['namaCourse'];
//   for ($i = 0; $i < $count_p; $i++) {
//     if( $data_idCourse[$count] == $percentage_idCourse[$i]) {
//       $data_percentage[$count] = $percentage[$i];
//       // echo $data_idCourse[$count];
//     }
//   }
//   $count++;
// }

$count = 0;
for($i=0; $i<10; $i++) {
  for ($j = 0; $j < $count_p; $j++) {
    if( $data_idCourse[$i] == $percentage_idCourse[$j]) {
      $data_percentage[$count] = $percentage[$j];
      // echo " hi ", $data_percentage[$count];
      $data_enrolledCourseName[$count] = $percentage_namaCourse[$j];
      // echo $data_idCourse[$count];
      $count++;
    }
  }
}


// var_dump($data_enrolledCourseName);

?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PoorBye - Course</title>
    <link rel="shortcut icon" href="/logo.png" type="image/x-icon" />
    <link href="css/course.css" rel="stylesheet" />
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script> -->
    <!-- <script src="js/jquery-3.2.1.min.js"></script> -->
    <!-- <script src="search.js"></script> -->
  </head>
  <body>
  <div class="coursePage">

      <div class="course_list">
        <div class="enrollCourse">
            <p id="status">Enroll Course</p>
            <div id="enrolled">
                
                
                <!-- <div id="enrolledCourse">
                <a href="course_programming.php">
                    <div id="gbrCourse">
                    <img src="ASSETS/ASSETS/Course/programming.png" />
                    </div>
                    <a id="courseName">PROGRAMMING</a>
                    <div id="progressBar"><div id="progressBar2">done</div></div>
                </a>
                </div> -->


                <!-- <div id="enrolledCourse">
                <a href="course_programming.php">
                    <div id="gbrCourse">
                    <img src="ASSETS/ASSETS/Course/design.png" />
                    </div>
                    <a id="courseName">DESIGN</a>
                    <div id="progressBar"><div id="progressBar2"></div></div>
                </a>
                </div> -->

                <!-- <button id="enrolledCourse">
                <div id="gbrCourse">
                    <img src="ASSETS/ASSETS/Course/design.png" />
                </div>
                <p id="courseName">DESIGN</p>
                <div id="progressBar"></div>
                </button> -->
            </div>
        </div>
        <div class="penawaran">
          <p id="ikuti">Ikuti kelas tambahan yang disarankan, dan capai pekerjaan sampingan terbaikmu!</p>
          <a href="#AllCourse" id="boxMulai">MULAI</a>
        </div>

        <div id="AllCourse">

                <p id="status">All Course</p>

                <div id="allcourse_container">
                    <?php foreach($allcourse_box as $item) : ?>
                        <div id="allcourse_box">
                            <a href="course_detail.php?nama=<?php echo $item['namaCourse']; ?>">
                                <div id="gbrCourse">
                                <img src="ASSETS/ASSETS/Course/<?php echo $item['namaCourse']; ?>.png" />
                                </div>
                                <p id="courseName"><?php echo $item['namaCourse']; ?></p>
                                <div id="capt">
                                    <div id="keterangan">
                                        <svg viewBox="0 0 29 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M21.1875 23.4375H7.1359C6.67021 23.4371 6.22372 23.2723 5.89442 22.9794C5.56512 22.6865 5.37992 22.2893 5.37946 21.875V3.125C5.37992 2.71073 5.56512 2.31354 5.89442 2.0206C6.22372 1.72767 6.67021 1.56291 7.1359 1.5625H21.1875C21.6532 1.56291 22.0996 1.72767 22.4289 2.0206C22.7582 2.31354 22.9434 2.71073 22.9439 3.125V16.1078L18.5528 14.1547L14.1617 16.1078V3.125H7.1359V21.875H21.1875V18.75H22.9439V21.875C22.9432 22.2892 22.7579 22.6863 22.4287 22.9792C22.0994 23.2721 21.6531 23.4369 21.1875 23.4375ZM18.5528 12.4078L21.1875 13.5797V3.125H15.9181V13.5797L18.5528 12.4078Z"
                                            fill="#59606D"
                                        />
                                        </svg>
                                        <div id="ket"><?php echo $item['topicCount']; ?> lessons</div>
                                    </div>
                                    <div id="keterangan2">
                                        <svg width="29" height="25" viewBox="0 0 29 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M14.7593 1.38889C12.289 1.38889 9.87411 2.04054 7.8201 3.26145C5.76608 4.48235 4.16517 6.21767 3.21981 8.24796C2.27445 10.2782 2.02711 12.5123 2.50905 14.6677C2.99099 16.823 4.18057 18.8028 5.92737 20.3567C7.67416 21.9107 9.89972 22.9689 12.3226 23.3976C14.7455 23.8263 17.2568 23.6063 19.5391 22.7653C21.8214 21.9244 23.7722 20.5002 25.1446 18.673C26.5171 16.8458 27.2496 14.6976 27.2496 12.5C27.2496 9.55315 25.9337 6.72699 23.5913 4.64325C21.2489 2.55952 18.072 1.38889 14.7593 1.38889ZM14.7593 22.2222C12.5978 22.2222 10.4848 21.652 8.6875 20.5837C6.89024 19.5154 5.48944 17.997 4.66225 16.2205C3.83506 14.444 3.61863 12.4892 4.04033 10.6033C4.46203 8.71736 5.50291 6.98502 7.03136 5.62535C8.55981 4.26567 10.5072 3.33972 12.6272 2.96458C14.7472 2.58945 16.9447 2.78198 18.9417 3.51783C20.9387 4.25369 22.6456 5.49981 23.8464 7.09862C25.0473 8.69743 25.6883 10.5771 25.6883 12.5C25.6883 15.0785 24.5369 17.5514 22.4873 19.3746C20.4377 21.1979 17.6579 22.2222 14.7593 22.2222Z"
                                            fill="#59606D"
                                        />
                                        <path
                                            d="M15.4775 12.7778V7.46529C15.4775 7.28111 15.3953 7.10448 15.2489 6.97424C15.1025 6.84401 14.9039 6.77084 14.6969 6.77084C14.4899 6.77084 14.2913 6.84401 14.1449 6.97424C13.9985 7.10448 13.9163 7.28111 13.9163 7.46529V13.5208L18.522 16.2986C18.6069 16.3554 18.7039 16.3962 18.807 16.4185C18.9102 16.4407 19.0174 16.4441 19.122 16.4283C19.2267 16.4125 19.3266 16.3778 19.4157 16.3265C19.5048 16.2751 19.5812 16.2082 19.6402 16.1296C19.6992 16.0511 19.7396 15.9628 19.7589 15.8699C19.7782 15.777 19.776 15.6816 19.7525 15.5896C19.7289 15.4975 19.6845 15.4106 19.6219 15.3343C19.5594 15.258 19.4799 15.1939 19.3886 15.1458L15.4775 12.7778Z"
                                            fill="#59606D"
                                        />
                                        <path
                                            d="M6.95296 12.4583C6.94582 11.209 7.31994 9.98146 8.03542 8.90645C8.75091 7.83145 9.78093 6.94934 11.0157 6.35416C12.2504 5.75898 13.6436 5.47305 15.0467 5.52686C16.4497 5.58067 17.8101 5.9722 18.9827 6.65971L19.6462 5.71526C18.5324 5.06624 17.2708 4.64471 15.9522 4.48095C14.6335 4.3172 13.2904 4.41529 12.0194 4.76818C10.7483 5.12107 9.58096 5.71999 8.60107 6.52193C7.62119 7.32386 6.85312 8.3089 6.35204 9.40629C5.85097 10.5037 5.62933 11.6862 5.70304 12.8688C5.77675 14.0514 6.14398 15.2049 6.77836 16.2463C7.41274 17.2876 8.29851 18.1911 9.37205 18.8918C10.4456 19.5924 11.6802 20.0729 12.9873 20.2986L13.1981 19.2361C11.4401 18.9169 9.85933 18.0687 8.7219 16.8342C7.58446 15.5998 6.95977 14.0545 6.95296 12.4583Z"
                                            fill="#59606D"
                                        />
                                        </svg>
                                        <div id="ket2"><?php echo $item['totalWaktu']; ?></div>
                                    </div>
                                </div>
                            </a>               
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
      </div>
    </div>
  </body>


  <script>
    // enrolled course

    
    var enrolled = document.getElementById('enrolled');
    enrolled.innerHTML  ='HALO';

  var enrolledCourse_count = <?php echo json_encode($enrolledCourse_count); ?>;
  console.log("hi"+enrolledCourse_count);
  if(enrolledCourse_count > 0) {
    var data_enrolledCourseName = <?php echo json_encode($data_enrolledCourseName); ?>;
  
    var enrolled = document.getElementById("enrolled");

    var percentage = <?php echo json_encode($data_percentage); ?>;
    console.log(percentage);

    count = 0;
    data_enrolledCourseName.forEach(element => {
      var enrolledCourse = document.createElement('div');
      enrolledCourse.setAttribute('id', "enrolledCourse");

      var link = document.createElement('a');
      link.setAttribute('href', "course_detail.php?nama=" +data_enrolledCourseName[count]);

      var gbrCourse = document.createElement('div');
      gbrCourse.setAttribute('id', "gbrCourse");

      var img = document.createElement('img');
      img.src = "ASSETS/ASSETS/Course/" + data_enrolledCourseName[count] + ".png";

      gbrCourse.appendChild(img);

      var courseName = document.createElement('a');
      courseName.setAttribute('id', "courseName");
      courseName.innerHTML = data_enrolledCourseName[count];

      var progressBar = document.createElement('div');
      progressBar.setAttribute('id', "progressBar");
      var progressBar2 = document.createElement('div');
      progressBar2.setAttribute('id', "progressBar2");
      progressBar2.style.width = percentage[count]*100+'%';

      if(progressBar2.style.width == "100%") {
        progressBar2.innerHTML = "COMPLETED";
        progressBar2.style.color = "white";
        progressBar2.style.height = "fit-content";        
      }

      progressBar.appendChild(progressBar2);
      link.appendChild(gbrCourse);
      link.appendChild(courseName);
      link.appendChild(progressBar);
      enrolledCourse.appendChild(link);
      enrolled.appendChild(enrolledCourse);

      count++;
    });

  }
  </script>
  
</html>
