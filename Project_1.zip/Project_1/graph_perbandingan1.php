<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>

<?php 

extract($_GET);

$idUser = $_SESSION["id"];
// var_dump($idUser);

$input_bulan1 = $_GET["input_bulan1"];
$input_tahun1 = $_GET["input_tahun1"];

    // echo "halooo";
$graph = mysqli_fetch_all(mysqli_query($link, "SELECT sum(nominal), day(tglTransaksi) 
from transaksi where idUser = $idUser AND idJenisTransaksi = 1 AND month(tglTransaksi) = $input_bulan1 AND year(tglTransaksi) = $input_tahun1 
group by tglTransaksi"), MYSQLI_ASSOC);
    
$maxY_graph = mysqli_fetch_all(mysqli_query($link, "SELECT max(sn)
    from (SELECT sum(nominal) as sn, day(tglTransaksi) from transaksi where idUser = $idUser AND idJenisTransaksi = 1 
    and month(tglTransaksi) = $input_bulan1 AND year(tglTransaksi) = $input_tahun1
    group by tglTransaksi) as t"), MYSQLI_ASSOC);
$maxX_graph = mysqli_fetch_all(mysqli_query($link, 'SELECT max(day(`tglTransaksi`)) from transaksi'), MYSQLI_ASSOC);

$maxY_js = $maxY_graph[0]['max(sn)'];
$maxX_js = $maxX_graph[0]['max(day(`tglTransaksi`))'];

$yarr = [];
$xarr = [];

$count = 0;
foreach($graph as $item) {

    $yarr[$count] = $item['sum(nominal)'];
    $xarr[$count] = $item['day(tglTransaksi)'];
    $count++;

}
$count = 0;

$row_nums = count($graph);

?>

<!DOCTYPE html>
<html lang="en-US">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Today's Date</title>
</head>
 
<body>
 
<div id="myPlot1" style="width:100%;"></div>

<script>

        var yArray = <?php echo json_encode($yarr) ?>;
        var xArray = <?php echo json_encode($xarr) ?>;
        var maxY = <?php echo json_encode($maxY_js) ?>;
        var maxX = <?php echo json_encode($maxX_js) ?>;
        var input_bulan = <?php echo json_encode($input_bulan1) ?>;
        var input_tahun = <?php echo json_encode($input_tahun1) ?>;
        var row_nums = <?php echo json_encode($row_nums) ?>;
        // console.log("hi" + row_nums);

        // console.log(yArray);

        if(row_nums == 0) {
            var boxgambarstatistic = document.getElementById("boxgambarstatistic2");
            // console.log(boxgambarstatistic);
            boxgambarstatistic.innerHTML = "No transaction";
            console.log(boxgambarstatistic);
        } else {
            // Define Data
            var trace1 = {
                x: xArray,
                y: yArray,
                type: "bar",
                marker: {
                    color: 'rgb(183,203,222)'
                }
            };
            var trace2 = {
                x: xArray,
                y: yArray,
                // yaxis: 'y2',
                type: "line",
                line: {
                    color: 'rgb(56,225,89)',
                    width: 5
                }
            };

            var data = [trace1, trace2];

            // Define Layout
            var layout = {
                xaxis: {range: [0, maxX], title: "Date"},
                yaxis: {range: [0, maxY], title: "Nominal"}, 
                // yaxis2: {range: [0, maxY], title: "Nominal"}, 
                title: transform_month(input_bulan) + " " + input_tahun,
                showlegend: false
                
            };

            var config = {responsive: true};

            // Display using Plotly
            Plotly.newPlot("myPlot1", data, layout, config);

            function transform_month(i) { 
                if(i == 1) return 'January'
                else if (i == 2) return 'February'
                else if (i == 3) return 'March'
                else if (i == 4) return 'April'
                else if (i == 5) return 'May'
                else if (i == 6) return 'June'
                else if (i == 7) return 'July'
                else if (i == 8) return 'August'
                else if (i == 9) return 'September'
                else if (i == 10) return 'October'
                else if (i == 11) return 'November'
                else if (i == 12) return 'December'
            }
        }
</script>




</body>
 
</html>