<?php include 'inc/header.php'; ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>7 Jurus Jitu Menyiapkan Modal Bagi Korban PHK yang Ingin Wirausaha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />
  </head>
  <link rel="shortcut icon" href="/LOGO.png" type="image/x-icon" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
  <link rel="stylesheet" href="css/newsStyle.css" />
  <body>
    <div class="container">
      <div class="lacak">
        <a href="home.php">Home</a>
        <p>> News</p>
      </div>
      <div class="judul">
        <h1>7 Jurus Jitu Menyiapkan Modal Bagi Korban PHK yang Ingin Wirausaha</h1>
      </div>
      <div class="tanggal">
        <p>Senin, 19 Desember 2022</p>
      </div>
      <img src="ASSETS/news/ilustrasi-mata-uang-rupiah-5_169 2.png" alt="" />
      <div class="teksBerita">
        <p>
          Gelombang pemutusan hubungan kerja (PHK) diperkirakan masih terus menghantui meski ekonomi Indonesia tumbuh tinggi. Hal ini disebabkan karena banyak industri yang lesu akibat kurangnya pesanan dari mitra dagangnya. Kendati, jika
          telah menjadi korban PHK, Anda jangan terlalu khawatir karena ada banyak cara untuk memiliki penghasilan lain. Salah satunya dengan berwirausaha. Soal modal, ada beberapa tips dari perencana keuangan untuk menyiapkan modal awal
          usaha. Berikut tipsnya:
        </p>
        <p style="font-weight: bold">1. Gunakan Pesangon dari Perusahaan</p>
        <p>
          Saat di PHK sudah tentu para pekerja mendapatkan uang pesangon dari perusahaan. Nah, uang tersebut bisa digunakan untuk bermodal usaha, namun setelah dikurangi dengan simpanan dana darurat. Dalam artian, saat menerima pesangon,
          dana tersebut jangan langsung dijadikan modal usaha. Tapi dipisahkan untuk dana darurat untuk biaya kehidupan sehari-hari minimal enam kali kebutuhan hidup dasar bulanan. "Karena usaha belum tentu bisa langsung menghasilkan profit
          yang stabil, sedangkan kebutuhan keluarga tetap harus diperhatikan," ujar Perencana Keuangan dari OneShildt Agustina Fitria kepada CNNIndonesia.com, Jumat (11/11). Setelah uang pesangon dibagikan dalam pos-pos kebutuhan. Jika ada
          sisa, maka bisa digunakan untuk biaya membuka usaha. "Jika dana darurat sudah memadai, maka pesangon dari perusahaan sebagian bisa digunakan untuk modal usaha," jelasnya.
        </p>
        <p style="font-weight: bold">2. Patungan</p>
        <p>
          Menurut Fitria, jika uang pesangon yang diterima tidak mencukupi untuk membuka usaha sendiri, maka bisa mencari partner kerja. Patungan dengan teman yang memiliki tujuan yang sama bisa menjadi salah satu solusi. "Jika tidak mampu
          melakukan semua sendiri, maka perlu mencari partner bisnis yang bisa diajak kerjasama dan bisa dipercaya. Tuangkan semua hal dalam perjanjian resmi (hitam di atas putih)," jelasnya.
        </p>
        <p style="font-weight: bold">3. Menjadi Dropshipper</p>
        <p>
          Selain itu, pekerja yang baru saja kena PHK juga bisa berwirausaha dengan menjadi dropshipper. Artinya, pekerja bisa menjual produk tanpa harus menyetok barangnya. Dalam hal ini, dropshipper bisa mempromosikan barang dari orang
          lain dan setelah ada pesanan baru dikirimkan ke pembeli. Jadi tak perlu modal usaha yang besar. "Jika memang modal sendiri sedikit dan belum ada partner, maka carilah usaha yang tidak membutuhkan modal, misalnya dengan metode
          dropshipper," jelasnya. Yang pasti, Fitria menekankan jangan sampai membuka usaha dengan modal dari utang. Apalagi utangnya berbunga. "Karena kondisinya saat ini tidak berpenghasilan dan usahanya belum jelas bisa langsung cukup
          untuk bayar cicilan atau tidak," imbuhnya.
        </p>
        <p style="font-weight: bold">4. Menggunakan Tabungan</p>
        <p>
          Sementara itu, Perencana Keuangan dari Advisor Alliance Group (AAG) Indonesia Dandy mengatakan para pekerja yang baru saja kena PHK juga bisa menggunakan tabungan yang sudah ada sebagai modal usaha. Senada dengan Fitria, ia
          menekankan sebelum menggunakan tabungan sebagai modal usaha, dana darurat untuk kebutuhan sehari-hari untuk beberapa bulan ke depan harus diamankan terlebih dahulu. "Kalau soal modal bisa diambil dari tabungan yang sudah ada,
          misal tabungan untuk tujuan jangka pendek, bisa digunakan terlebih dahulu," jelas Dandy.
        </p>
        <p style="font-weight: bold">5. Menjual Aset</p>
        <p>
          Menurut Dandy, cara lain yang bisa ditempuh untuk mendapat modal usaha adalah dengan menjual aset yang ada. Dalam hal ini aset yang tidak produktif, misalnya memiliki dua mobil atau sepeda motor, satunya bisa dijual. "Alternatif
          lainnya bisa menjual sebagian dari aset yang kita punya agar bisa dijadikan modal," imbuhnya. Sama dengan Fitria, jika tidak memiliki tabungan dan tak ada aset yang bisa dijual, maka cara lain bisa mencari investor untuk bagi
          hasil. "Di era digital bisa juga memanfaatkan crowdfunding dengan berbagai tipe yang memang sesuai dengan kebutuhan," jelasnya.
        </p>
        <p style="font-weight: bold">6. Pinjam Koperasi</p>
        <p>
          Salah satu cara yang bisa digunakan pekerja yang kena PHK untuk dapat modal kerja adalah meminjam ke koperasi. "Kalau kebetulan orang tersebut merupakan anggota koperasi, maka bisa memanfaatkan pinjaman dari koperasi," kata Dandy.
        </p>
        <p style="font-weight: bold">7. Manfaatkan KUR</p>
        <p>
          Cara lain untuk bisa mendapatkan modal usaha adalah memanfaatkan fasilitas kredit usaha rakyat (KUR). Di mana pinjaman ini diberikan dengan bunga sangat rendah karena sesuai tujuan pemerintah membantu masyarakat kelas bawah atau
          UMKM untuk menjalankan usahanya. "Opsi lain bisa menggunakan program dari pemerintah yg bekerja sama dengan bank konvensional dalam mengajukan Kredit Usaha Rakyat dengan bunga yang lebih rendah," pungkasnya.
        </p>
      </div>
      <div class="foot">
        <div class="leftFoot">
          <button class="reaction">
            <img src="ASSETS/news/like.png" alt="" />
            <p>0</p>
          </button>
          <button class="reaction">
            <img src="ASSETS/news/comment.png" alt="" />
            <p>0</p>
          </button>
        </div>
        <div class="rightFoot">
          <button>
            <img src="ASSETS/news/share.png" alt="" />
          </button>
          <button>
            <a href="home.php">
              <img src="ASSETS/news/home.png" alt="" />
            </a>
          </button>
        </div>
      </div>
    </div>
  </body>
</html>

<?php include 'inc/footer.php'; ?>