
var boxgambarstatistic = document.getElementById('boxgambarstatistic');
var bulantahun = document.getElementById('bulantahun');

console.log(boxgambarstatistic);

bulantahun.addEventListener('change', function() {
    
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // boxgambarstatistic.innerHTML = xhr.responseText;

    // buat line chart
    var tes = document.getElementById('MyPlot');
    console.log(xhr.responseText);

            var yArray = 
            console.log(yArray);
        // var xArray = <?php echo json_encode($xarr); ?>;
        // var maxY = <?php echo json_encode($maxY_js) ?>;
        // var maxX = <?php echo json_encode($maxX_js) ?>;

        console.log(yArray);
        
        // Define Data
        var trace1 = {
            x: xArray,
            y: yArray,
            type: "bar",
            line: {
                color: 'rgb(90, 210, 102)',
                width: 5
            }
        };
        var trace2 = {
            x: xArray,
            y: yArray,
            // yaxis: 'y2',
            type: "line",
            line: {
                color: 'rgb(90, 210, 102)',
                width: 5
            }
        };

        var data = [trace1, trace2];

        // Define Layout
        var layout = {
            xaxis: {range: [0, maxX], title: "Date"},
            yaxis: {range: [0, maxY], title: "Nominal"}, 
            // yaxis2: {range: [0, maxY], title: "Nominal"}, 
            title: "November 2022",
            showlegend: false
            
        };

        // Display using Plotly
        Plotly.newPlot("myPlot", data, layout);
        }
    }

    xhr.open('GET', 'graph.php', true);
    xhr.send();

});