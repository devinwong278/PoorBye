-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2023 at 02:18 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_poorbye2`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `idBerita` int(11) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`idBerita`, `judul`, `deskripsi`, `tanggal`, `link`) VALUES
(1, 'GoTo Respons Soal Isu PHK, Saham Melesat Hari Ini', 'PT GoTo Gojek Tokopedia Tbk (GOTO) buka suara terkait kabar akan melakukan pemutusan...', '2023-02-01', 'https://www.cnnindonesia.com/ekonomi/20221111140011-92-872531/goto-respons-soal-isu-phk-saham-melesat-hari-ini'),
(2, 'Inflasi AS Turun, Harga Emas Menguat di Rp974 per Gram', 'Harga jual emas PT Aneka Tambang (Persero) Tbk atau Antam berada di posisi...', '2023-01-31', 'https://www.cnnindonesia.com/ekonomi/20221111085211-92-872371/inflasi-as-turun-harga-emas-menguat-di-rp974-per-gram'),
(3, 'Menanti Rilis Data Inflasi AS, IHSG Diprediksi Lesu Pagi Ini', 'Indeks Harga Saham Gabungan (IHSG) diperkirakan melemah pada perdagangan Jumat (11/11)...', '2023-01-30', 'https://www.cnnindonesia.com/ekonomi/20221111055255-92-872310/menanti-rilis-data-inflasi-as-ihsg-diprediksi-lesu-pagi-ini'),
(4, '7 Jurus Jitu Menyiapkan Modal Bagi Korban PHK yang Ingin Wirausaha', 'Gelombang pemutusan hubungan kerja (PHK) diperkirakan masih terus menghantui...', '2023-01-24', 'https://www.cnnindonesia.com/ekonomi/20221111132951-83-872517/7-jurus-jitu-menyiapkan-modal-bagi-korban-phk-yang-ingin-wirausaha');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`idBerita`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `idBerita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
