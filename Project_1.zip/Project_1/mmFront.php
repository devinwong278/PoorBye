<?php include 'inc/header.php'; ?>


<?php
// buat bikin table history
    $idUser = $_SESSION["id"];
    $table_history = mysqli_fetch_all(mysqli_query($link, "SELECT 
    *,
    day(t.tglTransaksi),
    t.nominal,
    format(t.nominal, 0) as 'nominalF',
    date_format(t.tglTransaksi, '%m/%d/%Y') as 'tglTransaksiF'
    from transaksi t join aset a on t.idAset = a.idAset
    WHERE t.idUser = $idUser
    ORDER BY t.tglTransaksi DESC
    LIMIT 0, 5"), MYSQLI_ASSOC);
?>

<?php
// buat munculin informasi tujuan keuangan
// namaTarget, nominalTabung, idFrekuensi, nominal (from table aset), tglTarget 
      $idUser = $_SESSION["id"];
      $targets = mysqli_fetch_all(mysqli_query($link, "SELECT namaAset from aset where idUser = $idUser"), MYSQLI_ASSOC);
      $count = 0;
      foreach($targets as $item) {
        $category[$count] = $item['namaAset'];
        $count++;
      }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MM Front-PoorBye</title>
    <link rel="shortcut icon" href="/logo.png" type="image/x-icon" />
    <link href="css/mmFront.css" rel="stylesheet" />
  </head>
  <body>
    <div class="mmFront">
      <div class="atas">
        <div class="tujuanKeuangan">
          <div id="judul">Tujuan Keuangan</div>

          <div id="tujuanKeuangan_box">
            

            <!-- <div class="boxDana" id="">
              <div id="tongsampah">
                <img src="/ASSETS/moneyDelete.png" alt="" />
              </div>
              <div class="contentBox">
                <div id="addIcon">
                  <svg width="156" height="156" viewBox="0 0 156 156" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="78" cy="78" r="77.5" fill="#59606D" stroke="#F0FFF3" />
                    <path
                      d="M78 33C102.75 33 123 53.25 123 78C123 102.75 102.75 123 78 123C53.25 123 33 102.75 33 78C33 53.25 53.25 33 78 33ZM78 25.5C49.125 25.5 25.5 49.125 25.5 78C25.5 106.875 49.125 130.5 78 130.5C106.875 130.5 130.5 106.875 130.5 78C130.5 49.125 106.875 25.5 78 25.5Z"
                      fill="#F0FFF3"
                    />
                    <path d="M108 74.25H81.75V48H74.25V74.25H48V81.75H74.25V108H81.75V81.75H108V74.25Z" fill="#F0FFF3" />
                  </svg>
                </div>
                <div id="content">
                  <p id="name"></p>
                  <p id="name2"></p>
                  <div class="content2">
                    <div id="content21">
                      <p id="name"></p>
                      <p id="name2"></p>
                    </div>
                    <div id="content22">
                      <p id="name"></p>
                      <p id="name2"></p>
                    </div>
                  </div>
                </div>
              </div>
            </div> -->
          </div>

          <div class="addTarget">
            <div id="svgAdd">
              <svg width="43" height="43" viewBox="0 0 43 43" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M21.5 14.9195V28.5477M28.3333 21.7336H14.6667M42 21.7336C42 24.4181 41.4698 27.0764 40.4395 29.5565C39.4093 32.0367 37.8993 34.2903 35.9957 36.1885C34.0921 38.0868 31.8322 39.5925 29.345 40.6199C26.8578 41.6472 24.1921 42.1759 21.5 42.1759C18.8079 42.1759 16.1422 41.6472 13.655 40.6199C11.1678 39.5925 8.90791 38.0868 7.00431 36.1885C5.10071 34.2903 3.59069 32.0367 2.56047 29.5565C1.53025 27.0764 1 24.4181 1 21.7336C1 16.312 3.15981 11.1124 7.00431 7.27868C10.8488 3.445 16.0631 1.29126 21.5 1.29126C26.9369 1.29126 32.1512 3.445 35.9957 7.27868C39.8402 11.1124 42 16.312 42 21.7336Z"
                  stroke="#F0FFF3"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </div>
            <a id="newTarget" href="add_target.php">Add new target</a>
          </div>
        </div>
        <div id="pembatas"></div>
        <div class="target">
          <div id="judul">Total Assets</div>
          <div class="boxTarget">
            <div id="name11"></div>
            <div id="name22">Balance</div>
          </div>
          <div class="bawahBox">
              <!-- <div class="boxBawah" draggable="false">
                <div id="name13">Rp.1.500.000</div>
                <div id="name23">Tabungan</div>
              </div> -->
          </div>
          <div class="addTransaction">
            <div id="svgAdd">
              <svg width="43" height="43" viewBox="0 0 43 43" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M21.5 14.9195V28.5477M28.3333 21.7336H14.6667M42 21.7336C42 24.4181 41.4698 27.0764 40.4395 29.5565C39.4093 32.0367 37.8993 34.2903 35.9957 36.1885C34.0921 38.0868 31.8322 39.5925 29.345 40.6199C26.8578 41.6472 24.1921 42.1759 21.5 42.1759C18.8079 42.1759 16.1422 41.6472 13.655 40.6199C11.1678 39.5925 8.90791 38.0868 7.00431 36.1885C5.10071 34.2903 3.59069 32.0367 2.56047 29.5565C1.53025 27.0764 1 24.4181 1 21.7336C1 16.312 3.15981 11.1124 7.00431 7.27868C10.8488 3.445 16.0631 1.29126 21.5 1.29126C26.9369 1.29126 32.1512 3.445 35.9957 7.27868C39.8402 11.1124 42 16.312 42 21.7336Z"
                  stroke="#F0FFF3"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </div>
            <a id="newTarget" href="add_transaction_pemasukan.php">Add new transaction</a>
          </div>
        </div>
      </div>

      <!-- untuk mobile &tablet -->
      <div class="atasMobile">
        <div id="totalBalance">
          <p id="name11">Rp 4.500.000</p>
          <p id="name22">Balance</p>
        </div>
        <div id="assetsMobile">
          <div class="boxBawah">
            <div id="name13">Rp.1.500.000</div>
            <div id="name23">Tabungan</div>
          </div>
          <div class="boxBawah">
            <div id="name13">Rp.1.500.000</div>
            <div id="name23">Investasi</div>
          </div>
          <div class="boxBawah">
            <div id="name13">Rp.1.500.000</div>
            <div id="name23">Properti</div>
          </div>
        </div>
      </div>
      <div class="targetMobile">
        <div class="boxDana">
          <div class="contentBox">
            <!-- <div class="bagiContent"></div> -->
            <div id="addIcon">
              <svg width="156" height="156" viewBox="0 0 156 156" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="78" cy="78" r="77.5" fill="#59606D" stroke="#F0FFF3" />
                <path
                  d="M78 33C102.75 33 123 53.25 123 78C123 102.75 102.75 123 78 123C53.25 123 33 102.75 33 78C33 53.25 53.25 33 78 33ZM78 25.5C49.125 25.5 25.5 49.125 25.5 78C25.5 106.875 49.125 130.5 78 130.5C106.875 130.5 130.5 106.875 130.5 78C130.5 49.125 106.875 25.5 78 25.5Z"
                  fill="#F0FFF3"
                />
                <path d="M108 74.25H81.75V48H74.25V74.25H48V81.75H74.25V108H81.75V81.75H108V74.25Z" fill="#F0FFF3" />
              </svg>
            </div>
            <div class="textContent">
              <div id="content">
                <p id="name">DP Rumah</p>
                <p id="name2">Rp 2.500.000 / month</p>
              </div>
              <div id="content21">
                <p id="name">Balance</p>
                <p id="name2">Rp 88.000.000</p>
              </div>
              <div id="content22">
                <p id="name">Target</p>
                <p id="name2">1/11/2025</p>
              </div>
              <div id="tongsampah">
                <img src="/ASSETS/moneyDelete.png" alt="" />
              </div>
            </div>
          </div>
        </div>
        <div class="boxDana2">
          <div class="contentBox">
            <!-- <div class="bagiContent"></div> -->
            <div id="addIcon">
              <svg width="156" height="156" viewBox="0 0 156 156" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="78" cy="78" r="77.5" fill="#59606D" stroke="#F0FFF3" />
                <path
                  d="M78 33C102.75 33 123 53.25 123 78C123 102.75 102.75 123 78 123C53.25 123 33 102.75 33 78C33 53.25 53.25 33 78 33ZM78 25.5C49.125 25.5 25.5 49.125 25.5 78C25.5 106.875 49.125 130.5 78 130.5C106.875 130.5 130.5 106.875 130.5 78C130.5 49.125 106.875 25.5 78 25.5Z"
                  fill="#F0FFF3"
                />
                <path d="M108 74.25H81.75V48H74.25V74.25H48V81.75H74.25V108H81.75V81.75H108V74.25Z" fill="#F0FFF3" />
              </svg>
            </div>
            <div class="textContent">
              <div id="content">
                <p id="name">DP Rumah</p>
                <p id="name2">Rp 2.500.000 / month</p>
              </div>
              <div id="content21">
                <p id="name">Balance</p>
                <p id="name2">Rp 88.000.000</p>
              </div>
              <div id="content22">
                <p id="name">Target</p>
                <p id="name2">1/11/2025</p>
              </div>
              <div id="tongsampah">
                <img src="/ASSETS/moneyDelete.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- akhir mobile & tablet -->

      <div class="history">
        <div class="judul">
          <p id="judulHistory">History</p>
          <a id="viewAll" href="mmViewAllHistory.php">View All</a>
        </div>
        <div class="isi">
          <!-- <div class="judulTransaksi">
            <p>Nama Transaksi</p>
            <p>Nominal</p>
            <p>Category</p>
            <p>Date</pd=>
          </div>
          <div class="isiTransaksi">
            <p>Gaji</p>
            <p>+Rp1.500.000</p>
            <p>Tabungan</p>
            <p>2/11/2022</pd=>
          </div> -->
          <table>
            <thead>
              <tr>
                <th id="baris1">Nama Transaksi</th>
                <th>Nominal</th>
                <th>Category</th>
                <th id="judulbaris4">Date</th>
              </tr>
            </thead>
            
            <tbody>
            <?php $id = 1  ; ?> 
            <?php foreach($table_history as $item): ?>
                <tr>
                    <td style="text-align:left; padding: 10px;"><?php echo $item['namaTransaksi'] ? $item['namaTransaksi'] : '-'; ?></td>

                    <td style="text-align:center; padding-left: 50px; padding-right: 50px;color: <?php echo ($item['idJenisTransaksi'] == "1") ? "green" : "red"; ?>;"><?php echo ($item['idJenisTransaksi'] == "1" ? "+" : "-") . "Rp" . $item['nominalF']; ?></td>

                    <td style="text-align:center; padding-left: 50px; padding-right: 50px;"><?php echo $item['namaAset']; ?></td>
                    
                    <td style="text-align:right; padding-left: 50px; padding-right: 50px;"><?php echo $item['tglTransaksiF']; ?></td>
                </tr>
                <?php $id++; ?>
            <?php endforeach; ?>
              <tr>
                <td>...</td>
                <td>...</td>
                <td>...</td>
                <td>...</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </body>

  <?php

  $idUser = $_SESSION["id"];
  // var_dump($idUser);

  $result = mysqli_query($link, "SELECT *,
  format(nominal,0) as 'nominalF',
  format(nominalTabung, 0) as 'nominalTabungF'
  from aset a join targetkeuangan tk on a.namaAset = tk.namaTarget
  where a.idUser = $idUser and tk.idUser = $idUser");

  $tujuanKeuangan_box = mysqli_fetch_all($result, MYSQLI_ASSOC);
  // var_dump($tujuanKeuangan_box);

  // var_dump($total_aset);
  
  $data_idAset[] = '';
  $data_namaAset[] = '';
  $data_nominalTabung[] = ''; 
  $data_tglTarget[] = '';
  $data_balance[] = '';
  $data_frekuensi[] = '';
  $count = 0;
  if(count($tujuanKeuangan_box) > 0) {
    foreach($tujuanKeuangan_box as $item) {
      $data_idAset[$count] = $item['idAset']; 
      $data_namaAset[$count] = $item['namaAset']; 
      $data_nominalTabung[$count] = $item['nominalTabungF'];
      $data_tglTarget[$count] = $item['tglTarget'];
      $data_balance[$count] = $item['nominalF'];
  
      $data_frekuensi;
      if($item['idFrekuensi'] == 1) {
        $data_frekuensi[$count] = 'day';
      } elseif($item['idFrekuensi'] == 2) {
        $data_frekuensi[$count] = 'week';
      } elseif($item['idFrekuensi'] == 3) {
        $data_frekuensi[$count] = 'month';
      } elseif($item['idFrekuensi'] == 4) {
        $data_frekuensi[$count] = 'year';
      }
      $count++;
    }

  }
  

  // Total aset
  $total_aset = mysqli_fetch_all(mysqli_query($link, "SELECT format(sum(nominal),0) as 'nominalF'
  from aset
  where idUser = $idUser
  GROUP BY idUser"), MYSQLI_ASSOC);


  $aset = mysqli_fetch_all(mysqli_query($link, "SELECT *,
  format(nominal, 0) as 'nominalF'
  FROM `aset` 
  WHERE idUser = $idUser"), MYSQLI_ASSOC);

  // var_dump($aset);
  $count = 0;
  foreach($aset as $item) {
    $data_namaAset2[$count] = $item['namaAset'];
    $data_balance2[$count] = $item['nominalF'];

    $count++;
  }

?>





<script>

  console.log("mulai")
    // tujuan keuangan

  var data_idAset = <?php echo json_encode($data_idAset); ?>;
  var data_namaAset = <?php echo json_encode($data_namaAset); ?>;
  var data_nominalTabung = <?php echo json_encode($data_nominalTabung); ?>;
  var data_tglTarget = <?php echo json_encode($data_tglTarget); ?>;
  var data_frekuensi = <?php echo json_encode($data_frekuensi); ?>;
  var data_balance = <?php echo json_encode($data_balance); ?>;

  console.log(data_idAset);

  var tujuanKeuangan_box = document.getElementById("tujuanKeuangan_box");
    // console.log(tujuanKeuangan_box);

    var count = 0;

    if(!data_idAset[0] == '') {
      data_idAset.forEach(element => {
      
      var boxDana = document.createElement('div');
      boxDana.classList.add("boxDana")
      // console.log(boxDana);
      var tongsampah = document.createElement('a');
      tongsampah.setAttribute('id', "tongsampah");
      tongsampah.setAttribute('href', "mmFront_delete.php?idAset="+element);
      var img = document.createElement('img');
      img.src = 'ASSETS/ASSETS/moneyDelete.png';
      tongsampah.appendChild(img);
      tongsampah.setAttribute('onclick', "return confirm('yakin hapus "+element+"?')");
      // console.log(tongsampah);

      var contentBox = document.createElement('div');
      contentBox.classList.add("contentBox");
      var addicon = document.createElement('div');
      addicon.setAttribute('id', "addIcon");

      // var textArea = document.createElement("textArea");
      addicon.innerHTML = `<svg width="156" height="156" viewBox="0 0 156 156" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="78" cy="78" r="77.5" fill="#59606D" stroke="#F0FFF3" />
                    <path
                      d="M78 33C102.75 33 123 53.25 123 78C123 102.75 102.75 123 78 123C53.25 123 33 102.75 33 78C33 53.25 53.25 33 78 33ZM78 25.5C49.125 25.5 25.5 49.125 25.5 78C25.5 106.875 49.125 130.5 78 130.5C106.875 130.5 130.5 106.875 130.5 78C130.5 49.125 106.875 25.5 78 25.5Z"
                      fill="#F0FFF3"
                    />
                    <path d="M108 74.25H81.75V48H74.25V74.25H48V81.75H74.25V108H81.75V81.75H108V74.25Z" fill="#F0FFF3" />
                  </svg>`

      // console.log(addicon);

      var content = document.createElement('div');
      content.setAttribute('id', "content");
      var content21 = document.createElement('div');
      content21.setAttribute('id', "content21");
      var content22 = document.createElement('div');
      content22.setAttribute('id', "content22");

      var content2 = document.createElement('div');
      content2.setAttribute('class', "content2");

      var name_namaAset = document.createElement('p');
      var name_balance = document.createElement('p');
      var name_target = document.createElement('p');
      name_namaAset.setAttribute('id', "name");
      name_target.setAttribute('id', "name");
      name_balance.setAttribute('id', "name");

      var name2_nominalTabung = document.createElement('p');
      var name2_balance = document.createElement('p');
      var name2_tglTarget = document.createElement('p');
      name2_nominalTabung.setAttribute('id', "name2");
      name2_balance.setAttribute('id', "name2");
      name2_tglTarget.setAttribute('id', "name2"); 

      // name2_tglTarget = document.createTextNode(data_tglTarget[count]);
      name2_tglTarget.innerHTML = data_tglTarget[count];
      name_target.innerHTML ="Target";
      content22.appendChild(name_target);
      content22.appendChild(name2_tglTarget);

      name2_balance.textContent = "Rp " + data_balance[count];
      name_balance.innerHTML ="Balance";

      content21.appendChild(name_balance);
      content21.appendChild(name2_balance);
      // console.log(name2_balance);

      content2.appendChild(content21);
      content2.appendChild(content22);

      // console.log(content21);
      // console.log(content2);

      name_namaAset.innerHTML = data_namaAset[count];
      name2_nominalTabung.innerHTML = "Rp " + data_nominalTabung[count] + " / " + data_frekuensi[count];
      
      content.appendChild(name_namaAset);
      content.appendChild(name2_nominalTabung);
      content.appendChild(content2);
      // console.log(name2_nominalTabung);

      
      contentBox.appendChild(addicon);
      contentBox.appendChild(content);
      
      boxDana.appendChild(tongsampah);
      boxDana.appendChild(contentBox);
      
      tujuanKeuangan_box.appendChild(boxDana);
      // console.log(tujuanKeuangan_box);
      count++;

    });
    }

    


    

    // total aset
    var data_total_aset = <?php echo json_encode($total_aset[0]['nominalF']); ?>;
    var total_aset = document.getElementById("name11");
    // console.log(data_total_aset);
    total_aset.innerHTML = "Rp " + data_total_aset;

    // assetsMobile
    var data_namaAset2 = <?php echo json_encode($data_namaAset2); ?>;
    var data_balance2 = <?php echo json_encode($data_balance2); ?>;

    var bawahBox = document.getElementsByClassName("bawahBox")[0];
    // var carousel1 = document.getElementsByClassName("carousel")[0];
    // var carousel1 = document.querySelector(".carousel");
    // console.log(carousel1);
    var carousel1 = document.createElement('div');
    carousel1.setAttribute('class', "carousel");
    carousel1.setAttribute('id', "carousel");
    // carousel1.style.cssText = "display: flex; flex-direction: row; width: 50vw; white-space: nowrap; overflow: hidden; white-space: nowrap; scroll-behavior: smooth;";
    
    count = 0;

    data_namaAset2.forEach(element => {
      var boxBawah = document.createElement('div');
      boxBawah.setAttribute('class', "boxBawah");
      boxBawah.setAttribute('draggable', "false");
      
      var name13 = document.createElement('div');
      name13.setAttribute('id', "name13");
      var name23 = document.createElement('div');
      name23.setAttribute('id', "name23");

      name13.innerHTML = "Rp " + data_balance2[count];
      name23.innerHTML = data_namaAset2[count];

      boxBawah.appendChild(name13);
      boxBawah.appendChild(name23);
      // console.log(boxBawah);

      carousel1.appendChild(boxBawah);

      count++;
    })

    bawahBox.appendChild(carousel1);
    console.log(bawahBox);

    var tombol_hapus = document.getElementById("tongsampah");
    console.log(tombol_hapus);

    // tombol_hapus.onclick = function() {
    //   return confirm('yakin?');
    // }

  </script>

  <script>
    // console.log("hi");


const carousel = document.querySelector(".carousel"),
  firstImg = carousel.querySelectorAll("boxBawah")[0],
  arrowIcons = document.querySelectorAll(".newsBox i");

let isDragStart = false,
  isDragging = false,
  prevPageX,
  prevScrollLeft,
  positionDiff;


const autoSlide = () => {
  // if there is no image left to scroll then return from here
  if (carousel.scrollLeft - (carousel.scrollWidth - carousel.clientWidth) > -1 || carousel.scrollLeft <= 0) return;
  positionDiff = Math.abs(positionDiff); // making positionDiff value to positive
  let firstImgWidth = firstImg.clientWidth + 14;
  // getting difference value that needs to add or reduce from carousel left to take middle img center
  let valDifference = firstImgWidth - positionDiff;
  if (carousel.scrollLeft > prevScrollLeft) {
    // if user is scrolling to the right
    return (carousel.scrollLeft += positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff);
  }
  // if user is scrolling to the left
  carousel.scrollLeft -= positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
};
const dragStart = (e) => {
  // updatating global variables value on mouse down event
  isDragStart = true;
  prevPageX = e.pageX || e.touches[0].pageX;
  prevScrollLeft = carousel.scrollLeft;
};
const dragging = (e) => {
  // scrolling images/carousel to left according to mouse pointer
  if (!isDragStart) return;
  e.preventDefault();
  isDragging = true;
  carousel.classList.add("dragging");
  positionDiff = (e.pageX || e.touches[0].pageX) - prevPageX;
  carousel.scrollLeft = prevScrollLeft - positionDiff;
  showHideIcons();
};
const dragStop = () => {
  isDragStart = false;
  carousel.classList.remove("dragging");
  if (!isDragging) return;
  isDragging = false;
  autoSlide();
};
carousel.addEventListener("mousedown", dragStart);
carousel.addEventListener("touchstart", dragStart);
document.addEventListener("mousemove", dragging);
carousel.addEventListener("touchmove", dragging);
document.addEventListener("mouseup", dragStop);
carousel.addEventListener("touchend", dragStop);

const slider3 = document.querySelector(".carousel2");
// console.log(slider3);
  // Box3 = slider3.querySelectorAll("boxBawah")[0];
let mulaiDrag3 = false,
  areDrag3 = false,
  befPageX3,
  BefScrollKiri3,
  selisih3;

const Slideauto3 = () => {
  // if there is no image left to scroll then return from here
  if (slider3.scrollLeft - (slider3.scrollWidth - slider3.clientWidth) > -1 || slider3.scrollLeft <= 0) return;
  selisih3 = Math.abs(selisih3); // making selisih3 value to positive
  let Box3Width = Box3.clientWidth + 14;
  // getting difference value that needs to add or reduce from slider3 left to take middle img center
  let selisih3Count = Box3Width - selisih3;
  if (slider3.scrollLeft > BefScrollKiri3) {
    // if user is scrolling to the right
    return (slider3.scrollLeft += selisih3 > Box3Width / 3 ? selisih3Count : -selisih3);
  }
  // if user is scrolling to the left
  slider3.scrollLeft -= selisih3 > Box3Width / 3 ? selisih3Count : -selisih3;
};
const StartDrag3 = (e) => {
  // updatating global variables value on mouse down event
  mulaiDrag3 = true;
  befPageX3 = e.pageX || e.touches[0].pageX;
  BefScrollKiri3 = slider3.scrollLeft;
};
const dragging3 = (e) => {
  // scrolling images/slider3 to left according to mouse pointer
  if (!mulaiDrag3) return;
  e.preventDefault();
  areDrag3 = true;
  slider3.classList.add("dragging3");
  selisih3 = (e.pageX || e.touches[0].pageX) - befPageX3;
  slider3.scrollLeft = BefScrollKiri3 - selisih3;
  showHideIcons();
};
const stopDrag3 = () => {
  mulaiDrag3 = false;
  slider3.classList.remove("dragging3");
  if (!areDrag3) return;
  areDrag3 = false;
  Slideauto3();
};
slider3.addEventListener("mousedown", StartDrag3);
slider3.addEventListener("touchstart", StartDrag3);
document.addEventListener("mousemove", dragging3);
slider3.addEventListener("touchmove", dragging3);
document.addEventListener("mouseup", stopDrag3);
slider3.addEventListener("touchend", stopDrag3);
  </script>

<!-- <script src="mmFront.js"></script> -->

</html>


<?php include 'inc/footer.php'; ?>