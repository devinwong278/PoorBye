<?php include 'inc/header.php'; ?>

<?php
// buat bikin table history
  $idUser = $_SESSION["id"];
  $result = mysqli_query($link, "SELECT 
            *,
            day(t.tglTransaksi),
            t.nominal
            from transaksi t
            where idUser = $idUser");
      // $table_history = mysqli_fetch_all($result , MYSQLI_ASSOC);

  $data_count = mysqli_num_rows($result);
  $data_per_page = 8;
  $page_count = ceil($data_count / $data_per_page);
  if(isset($_GET["page"])) {
    $active_page = $_GET["page"];
  } else {
  $active_page = 1;
  }

  $first_data = ($active_page - 1) * $data_per_page; 
    
  $table_history = mysqli_fetch_all(mysqli_query($link, "SELECT 
  *,
  day(t.tglTransaksi),
  t.nominal,
  format(t.nominal, 0) as 'nominalF',
  date_format(t.tglTransaksi, '%m/%d/%Y') as 'tglTransaksiF'
  from transaksi t join aset a on t.idAset = a.idAset
  WHERE t.idUser = $idUser
  ORDER BY t.tglTransaksi DESC, idTransaksi ASC
  LIMIT $first_data, $data_per_page"), MYSQLI_ASSOC);

// var_dump($table_history);

// BUAT DROPDOWN CATEGORY
$namaAset = mysqli_fetch_all(mysqli_query($link, "SELECT namaAset FROM aset WHERE idUser = $idUser"));
  // var_dump($namaAset); 
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MM - View All History</title>
    <link rel="shortcut icon" href="/logo.png" type="image/x-icon" />
    <link href="css/mmViewAllHistory.css" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  </head>
  <body>
    <div class="allHistory">
      <div class="history">
        <div class="judul">
          <p id="judulHistory">History</p>
          <!-- <a id="viewAll" href="/mmHistory.html">View Less</a> -->
          <input type="date" id="viewAll" ></input>
        </div>
        <div class="isi" id="isi">
          <table>
            <thead>
              <tr>
                <th id="baris1">Nama Transaksi</th>
                <th>Nominal</th>
                <th>
                  <div class="selectCategory">
                    <select name="" id="selectArea">
                      <option value="all">Category (All)</option>
                      <?php foreach($namaAset as $item) : ?>
                        <option value="<?php echo $item[0]; ?>"><?php echo $item[0];?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </th>
                <th id="judulbaris4">Date</th>
              </tr>
            </thead>
            <tbody id="tbody">
            <?php $id = 1  ; ?> 
            <?php foreach($table_history as $item): ?>
                <tr>
                    <td style="text-align:left; padding: 10px;"><?php echo $item['namaTransaksi'] ? $item['namaTransaksi'] : '-'; ?></td>
                    <td style="text-align:center; padding-left: 50px; padding-right: 50px;color: <?php echo ($item['idJenisTransaksi'] == "1") ? "green" : "red"; ?>;"><?php echo ($item['idJenisTransaksi'] == "1" ? "+" : "-") . "Rp" . $item['nominalF']; ?></td>
                    <td style="text-align:center; padding-left: 50px; padding-right: 50px;"><?php echo $item['namaAset']; ?></td>
                    <td style="text-align:right; padding-left: 50px; padding-right: 50px;"><?php echo $item['tglTransaksiF']; ?></td>
                </tr>
                <?php $id++; ?>
            <?php endforeach; ?>
            <!-- <p id="error_message">No Transaction</p> -->
            </tbody>

          </table>

          <div class="pagination">
              <div class="left_pagination">
                <?php if($active_page > 1) : ?>
                  <a href="?page=<?= $active_page - 1?>">&laquo</a>
                <?php endif; ?>
              </div>

              <div class="numbers">
              <?php for ($i = 1; $i <= $page_count; $i++) :  ?>
                <?php if($i == $active_page) : ?>
                    <div class="active_page">
                      <a href="?page=<?=$i;?>"><?= $i; ?> </a>
                    </div>
                <?php else : ?>
                    <a href="?page=<?=$i;?>"><?= $i; ?> </a>
                <?php endif; ?>
              <?php endfor; ?>
              </div>

              <div class="right_pagination">
                <?php if($active_page < $page_count) : ?>
                  <a href="?page=<?= $active_page + 1?>">&raquo</a>
                <?php endif; ?>
              </div>
            </div>
          
            
          
              
        </div>
      </div>
    </div>
  </body>

  <script>
    var date_viewAll = document.getElementById('viewAll');
    var category = document.getElementById('selectArea');

    value_date = date_viewAll.value;
    value_category = category.value;
    console.log(category.value);
    console.log(viewAll.value);

    $(document).ready(function() {
      $('#viewAll').change(function(e) {
        e.preventDefault();


        value_date = date_viewAll.value;
        // console.log(value_date);

        $.ajax({
          url: 'mmViewAllHistorySearch.php',
          data: {value_date: value_date, value_category: value_category},
          method: 'POST',
          success: function(resp) {
            $('#tbody').html(resp);
          }
        })
      })


      $('#selectArea').change(function(e) {
        e.preventDefault();


        value_category = category.value;
        // console.log(value_date);

        $.ajax({
          url: 'mmViewAllHistorySearch.php',
          data: {value_date: value_date, value_category: value_category},
          method: 'POST',
          success: function(resp) {
            // console.log(category.value);
    // console.log(viewAll.value);
            $('#tbody').html(resp);
          }
        })
      })
    })

    

  </script>
</html>

<?php include 'inc/footer.php'; ?>