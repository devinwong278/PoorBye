<?php include 'inc/header.php'; ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BBCA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />
  </head>
  <link rel="shortcut icon" href="/LOGO.png" type="image/x-icon" />
  <link rel="stylesheet" href="css/stock_detail.css" />
  <body>
    <div class="bbcaPage">
      <!-- bagian stock & sreach -->
      <div class="stSearch">
        <h2>Stocks</h2>
        <div class="search">
          <input type="text" placeholder="Cari Kode Saham" name="search" id="search" />
          <button>
            <img src="ASSETS/keperluan bbca/search.png" alt="" />
          </button>
        </div>
      </div>
      <!-- bagian grafik dan info bbca -->
      <div class="bcaTrade">
        <div class="bcaBox">
          <h1>BBCA</h1>
          <div class="period">
            <button class="time">1D</button>
            <button class="time">1W</button>
            <button class="time">1M</button>
            <button class="time">3M</button>
            <button class="time">1Y</button>
            <button class="time">5Y</button>
            <button class="time">ALL</button>
            <div class="price">
              <h3>8750</h3>
              <p>0(0%)</p>
            </div>
          </div>
          <img src="/keperluan home/grafikBCA.png" alt="" />
        </div>
        <div class="sahamBox">
          <div class="white">
            <div class="bca">
              <h1>BBCA</h1>
              <p>Bank Central Asia Tbk</p>
            </div>
            <div class="price2">
              <h3>8.750</h3>
              <p>0(0%)</p>
            </div>
            <table class="saham-table">
              <tr>
                <td id="abu">Open</td>
                <td>8.775</td>
                <td id="abu">Vol(Share)</td>
                <td>31M</td>
              </tr>
              <tr>
                <td id="abu">High</td>
                <td>8.850</td>
                <td id="abu">Mkt Cap</td>
                <td>1068 T</td>
              </tr>
              <tr>
                <td id="abu">Low</td>
                <td>8.750</td>
                <td id="abu">Foreign Buy</td>
                <td>0</td>
              </tr>
              <tr>
                <td id="abu">Close</td>
                <td>8.750</td>
                <td id="abu">Foreign Sell</td>
                <td>0</td>
              </tr>
              <tr>
                <td id="abu">52 WK High</td>
                <td>9000</td>
                <td id="abu">Turnover%</td>
                <td>0,03%</td>
              </tr>
              <tr>
                <td id="abu">52 WK Low</td>
                <td>7.000</td>
                <td id="abu">Tradeable</td>
                <td>122 B</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      <!-- bagian top2 an  -->
      <div class="top">
        <div class="topBox">
          <h2>Top Volume</h2>
          <table class="top-table">
            <thead>
              <td>Kode</td>
              <td>Notasi</td>
              <td>Volume</td>
              <td>Harga</td>
              <td>Change</td>
            </thead>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
          </table>
        </div>
        <div class="topBox">
          <h2>Top Gainer</h2>
          <table class="top-table">
            <thead>
              <td>Kode</td>
              <td>Notasi</td>
              <td>Volume</td>
              <td>Harga</td>
              <td>Change</td>
            </thead>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
          </table>
        </div>
        <div class="topBox">
          <h2>Top Loser</h2>
          <table class="top-table">
            <thead>
              <td>Kode</td>
              <td>Notasi</td>
              <td>Volume</td>
              <td>Harga</td>
              <td>Change</td>
            </thead>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
            <tr>
              <td>BUMI</td>
              <td></td>
              <td>1,46 B</td>
              <td>Rp 176</td>
              <td id="turun">-4(-2,22%)</td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  </body>
</html>

<?php include 'inc/footer.php'; ?>