<?php include 'inc/header.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Money Management - PoorBye</title>
    <link rel="stylesheet" href="css/statistics_pemasukan.css">
</head>
<body> 

    <div class="batas">

        <div class="boxjudul">
            <div class="judul">Statistic</div>
        </div>

        <div class="boxpilihan">
            <div class="pemasukan-container">
                <a href="statistics_pemasukan.php" style="text-decoration: none">Pemasukan</a>
            </div>
            <div class="pengeluaran-container">
                <a href="statistics_pengeluaran.php" style="text-decoration: none">Pengeluaran</a>
            </div>
        </div>
        
        <div class="boxstatistic">
            <div class="boxpilihanwaktu1">
                <select id="bulantahun" name="bulantahun">

                </select>

                <select id="range" name="range">
                    <option value="Harian">Harian</option>
                    <option value="Bulanan">Bulanan</option>
                </select>
            </div>

            <div class="boxgambarstatistic" id="boxgambarstatistic">
                <!-- <div id="myPlot" style="width:100%;max-width:700px"></div> -->
            </div>

            <div class="boxjudulPerbandinganAntara">
                <div class="judulPerbandinganAntara">Perbandingan antara</div>
            </div>

            <div class="boxpilihanwaktu2">
                <select id="bulantahun1">
                    <!-- option -->
                </select>
                <div class="vs">VS</div>
                <select id="bulantahun2">
                    <!-- option -->
                </select>
            </div> 
            <div class="boxGenerate">
                <div class="generate-container">
                    <a href="#boxgambarstatistic2" style="text-decoration: none" id="generate">Generate</a>
                </div>
            </div>

            <div class="boxgambarstatistic2">
                <div id="boxgambarstatistic2"></div>
                <div id="boxgambarstatistic3"></div>
            </div>


        </div>


    </div>
</body>

<!-- buat list dropdown bulan tahun frekuensi HARIAN-->
<?php

    $idUser = $_SESSION["id"];
    $bulantahun = mysqli_fetch_all(mysqli_query($link, "SELECT
    *,
    month(min(tglTransaksi)),
    year(min(tglTransaksi)),
    month(max(tglTransaksi)),
    year(max(tglTransaksi))
    FROM transaksi where idUser = $idUser and idJenisTransaksi = 1"), MYSQLI_ASSOC);
    $count = 0;

    // var_dump($bulantahun);

// print_r($bulantahun);
$bulanmin = $bulantahun[0]['month(min(tglTransaksi))'];
$tahunmin = $bulantahun[0]['year(min(tglTransaksi))'];
$bulanmax = $bulantahun[0]['month(max(tglTransaksi))'];
$tahunmax = $bulantahun[0]['year(max(tglTransaksi))'];
// var_dump($tahunmin);

?>

<!-- buat list dropdown tahun bulan dan show graph-->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<script>


    var bulanmin = <?php echo json_encode($bulanmin); ?>;
    var tahunmin = <?php echo json_encode($tahunmin); ?>;
    var bulanmax = <?php echo json_encode($bulanmax); ?>;
    var tahunmax = <?php echo json_encode($tahunmax); ?>;
    // console.log(bulanmax);

    // default pas muncul

    var range = document.getElementById('range');
    var value_range = range.value;
    console.log(value_range);

    // dropdown bulantahun

    var months = [];
    var years = [];
    var monthyears = [];
    if(tahunmin != tahunmax) {
        for(let i = tahunmin; i <= tahunmax; i++) {
            if( i == tahunmin) {
                for(let j = bulanmin; j <= 12; j++) {
                    months.push(j);
                    monthyears.push(transform_month(j) + ' ' + i);
                    years.push(i);
                }
            } else if (i == tahunmax) {
                for(let j = 1; j <= bulanmax; j++) {
                    months.push(j);
                    monthyears.push(transform_month(j) + ' ' + i);
                    years.push(i);
                }
            } else {
                for(let j = 1; j <= 12; j++) {
                    months.push(j);
                    monthyears.push(transform_month(j) + ' ' + i);
                    years.push(i);
                }
            }
        }

    } else {
        for(let i = bulanmin; i <= bulanmax; i++) {
            months.push(i);
            monthyears.push(transform_month(i) + ' ' + tahunmin);
            years.push(tahunmin);
        }
    }

    // console.log(months);

    var element3 = document.getElementById("bulantahun");
    element3.options.length = 0;
    monthyears.forEach(element => {
        var para2 = document.createElement("option");
        var node2 = document.createTextNode(element);
        para2.appendChild(node2);
        var element2 = document.getElementById("bulantahun");
        element2.appendChild(para2);
    });

    function transform_month(i) { 
        if(i == 1) return 'January'
        else if (i == 2) return 'February'
        else if (i == 3) return 'March'
        else if (i == 4) return 'April'
        else if (i == 5) return 'May'
        else if (i == 6) return 'June'
        else if (i == 7) return 'July'
        else if (i == 8) return 'August'
        else if (i == 9) return 'September'
        else if (i == 10) return 'October'
        else if (i == 11) return 'November'
        else if (i == 12) return 'December'
    }

    // dropdown bulantahun1 default
    var bulantahun1 = document.getElementById("bulantahun1");
    bulantahun1.options.length = 0;
    monthyears.forEach(element => {
        var para2 = document.createElement("option");
        var node2 = document.createTextNode(element);
        para2.appendChild(node2);
        var element2 = document.getElementById("bulantahun1");
        element2.appendChild(para2);
    });
    
    // dropdown bulantahun2 default
    var bulantahun2 = document.getElementById("bulantahun2");
    bulantahun2.options.length = 0;
    value_bulantahun1 = bulantahun1.value;
    monthyears.forEach(element => {
        var para2 = document.createElement("option");
        var node2 = document.createTextNode(element);
        para2.appendChild(node2);
        var element2 = document.getElementById("bulantahun2");
        if(element != value_bulantahun1) {
            element2.appendChild(para2);
        }
    });

    // dropdown bulantahun perbandingan setelah click
    bulantahun1.onclick = function() {
        bulantahun2.options.length = 0;
        value_bulantahun1 = bulantahun1.value;

        monthyears.forEach(element => {
        var para2 = document.createElement("option");
            var node2 = document.createTextNode(element);
            para2.appendChild(node2);
            if(element != value_bulantahun1) {
                bulantahun2.appendChild(para2);
            }
        });
    }

    var bulantahun = document.getElementById('bulantahun');
    var value_bulantahun = bulantahun.value;
    for(let i = 0; i < monthyears.length; i++) {
        if(value_bulantahun == monthyears[i]) {
            input_bulan = months[i];
            input_tahun = years[i];
            break;
        }
    }

    $(document).ready(function() {
        $('#bulantahun').ready(function(e) {
            // e.preventDefault()

            value_bulantahun = bulantahun.value;
            for(let i = 0; i < monthyears.length; i++) {
                if(value_bulantahun == monthyears[i]) {
                    input_bulan = months[i];
                    input_tahun = years[i];
                    break;
                }
            } 
                
            var arr_bulantahun = [input_bulan, input_tahun];
            console.log(arr_bulantahun);

            $.ajax({
                url: 'graph2.php',
                data: {input_bulan: input_bulan, input_tahun: input_tahun, value_range: value_range},
                method: 'POST',
                success: function(resp) {
                    $('#boxgambarstatistic').html(resp);
                }
            })
        })

        $('#bulantahun').change(function(e) {
            e.preventDefault()

            value_bulantahun = bulantahun.value;
            for(let i = 0; i < monthyears.length; i++) {
                if(value_bulantahun == monthyears[i]) {
                    input_bulan = months[i];
                    input_tahun = years[i];
                    break;
                }
            }
                
            var arr_bulantahun = [input_bulan, input_tahun];
            console.log(arr_bulantahun);

            $.ajax({
                url: 'graph2.php',
                data: {input_bulan: input_bulan, input_tahun: input_tahun, value_range: value_range},
                method: 'POST',
                success: function(resp) {
                    $('#boxgambarstatistic').html(resp);
                }
            })
        })
    });




    // kalo range mulai di click

    range.onchange = function() {
        
        value_range = range.value;

        if(value_range == "Harian") {

            //dropdown

            var months = [];
            var years = [];
            var monthyears = [];
            if(tahunmin != tahunmax) {
                for(let i = tahunmin; i <= tahunmax; i++) {
                    if( i == tahunmin) {
                        for(let j = bulanmin; j <= 12; j++) {
                            months.push(j);
                            monthyears.push(transform_month(j) + ' ' + i);
                            years.push(i);
                        }
                    } else if (i == tahunmax) {
                        for(let j = 1; j <= bulanmax; j++) {
                            months.push(j);
                            monthyears.push(transform_month(j) + ' ' + i);
                            years.push(i);
                        }
                    } else {
                        for(let j = 1; j <= 12; j++) {
                            months.push(j);
                            monthyears.push(transform_month(j) + ' ' + i);
                            years.push(i);
                        }
                    }
                }

            } else {
                for(let i = bulanmin; i <= bulanmax; i++) {
                    months.push(i);
                    monthyears.push(transform_month(i) + ' ' + tahunmin);
                    years.push(tahunmin);
                }
            }

            var element3 = document.getElementById("bulantahun");
            element3.options.length = 0;
            monthyears.forEach(element => {
                var para2 = document.createElement("option");
                var node2 = document.createTextNode(element);
                para2.appendChild(node2);
                var element2 = document.getElementById("bulantahun");
                element2.appendChild(para2);
            });

            function transform_month(i) { 
                if(i == 1) return 'January'
                else if (i == 2) return 'February'
                else if (i == 3) return 'March'
                else if (i == 4) return 'April'
                else if (i == 5) return 'May'
                else if (i == 6) return 'June'
                else if (i == 7) return 'July'
                else if (i == 8) return 'August'
                else if (i == 9) return 'September'
                else if (i == 10) return 'October'
                else if (i == 11) return 'November'
                else if (i == 12) return 'December'
            }

            var bulantahun = document.getElementById('bulantahun');
            var value_bulantahun = bulantahun.value;
            for(let i = 0; i < monthyears.length; i++) {
                if(value_bulantahun == monthyears[i]) {
                    input_bulan = months[i];
                    input_tahun = years[i];
                    break;
                }
            }

            $(document).ready(function() {
                $('#bulantahun').ready(function(e) {
                        // e.preventDefault()

                    value_bulantahun = bulantahun.value;
                    for(let i = 0; i < monthyears.length; i++) {
                        if(value_bulantahun == monthyears[i]) {
                            input_bulan = months[i];
                            input_tahun = years[i];
                            break;
                        }
                    }
                    console.log("day ready")

                    $.ajax({
                        url: 'graph2.php',
                        data: {input_bulan: input_bulan, input_tahun: input_tahun, value_range: value_range},
                        method: 'POST',
                        success: function(resp) {
                            $('#boxgambarstatistic').html(resp);
                        }
                    })
                })

            });


        } else if (value_range == "Bulanan") {

            // dropdown

            var years2 = [];
            for(let i = tahunmin; i <= tahunmax; i++) {
                years2.push(i);
            }
            // console.log(years2);

            var element3 = document.getElementById("bulantahun");
            element3.options.length = 0;
            years2.forEach(element => {
                var para2 = document.createElement("option");
                var node2 = document.createTextNode(element);
                para2.appendChild(node2);
                var element2 = document.getElementById("bulantahun");
                element2.appendChild(para2);
            });

            var bulantahun = document.getElementById('bulantahun');
            var value_bulantahun = bulantahun.value;
            console.log("tes" + value_bulantahun);
            

            
            $(document).ready(function() {
                $('#bulantahun').ready(function(e) {
                    // e.preventDefault()

                    value_bulantahun = bulantahun.value;
                    // console.log("month ready");
                    
                    // var arr_bulantahun = [input_bulan, input_tahun];
                    // console.log(arr_bulantahun);
                    
                    $.ajax({
                        url: 'graph2.php',
                        data: {input_tahun: value_bulantahun, value_range: value_range},
                        method: 'POST',
                        success: function(resp) {
                            $('#boxgambarstatistic').html(resp);
                            
                        }
                    })
                })
                
            });

        }

        $(document).ready(function() {
            $('#bulantahun').click(function(e) {
                e.preventDefault();

                if(value_range == "Harian") {
                    value_bulantahun = bulantahun.value;
                    for(let i = 0; i < monthyears.length; i++) {
                        if(value_bulantahun == monthyears[i]) {
                            input_bulan = months[i];
                            input_tahun = years[i];
                            break;
                        }
                    } 
                } else if(value_range == "Bulanan") {
                    input_tahun = bulantahun.value;
                    input_bulan = "";
                }
                
                
                // var arr_bulantahun = [input_bulan, input_tahun];
                // console.log(arr_bulantahun);

                $.ajax({
                    url: 'graph2.php',
                    data: {input_bulan: input_bulan, input_tahun: input_tahun, value_range: value_range},
                    method: 'POST',
                    success: function(resp) {
                        $('#boxgambarstatistic').html(resp);

                    }
                })
            })
        });
    }

    


    // buat tombol generate graph
    var generate = document.getElementById("generate");
    var bulantahun1 = document.getElementById("bulantahun1");
    var bulantahun2 = document.getElementById("bulantahun2");


    console.log(bulantahun1.value);
    console.log(bulantahun2.value);
    // buat graph bulantahun1
    

    $(document).ready(function() {
        $('#generate').click(function(e) {
            e.preventDefault()

             // graph kanan
            var value_bulantahun2 = bulantahun2.value;
            for(let i = 0; i < monthyears.length; i++) {
                if(value_bulantahun2 == monthyears[i]) {
                    input_bulan2 = months[i];
                    input_tahun2 = years[i];
                    break;
                }
            }
            // console.log(value_bulantahun1);
            $.ajax({
                url: 'graph_perbandingan2.php',
                data: {input_bulan2: input_bulan2, input_tahun2: input_tahun2},
                method: 'GET',
                success: function(resp) {
                    console.log(bulantahun2);
                    $('#boxgambarstatistic3').html(resp);
                }
            })
            
            //graph kiri
            var value_bulantahun1 = bulantahun1.value;
            for(let i = 0; i < monthyears.length; i++) {
                if(value_bulantahun1 == monthyears[i]) {
                    input_bulan1 = months[i];
                    input_tahun1 = years[i];
                    break;
                }
            }
            // console.log(value_bulantahun1);    
            $.ajax({
                url: 'graph_perbandingan1.php',
                data: {input_bulan1: input_bulan1, input_tahun1: input_tahun1},
                method: 'GET',
                success: function(resp) {
                    $('#boxgambarstatistic2').html(resp);
                }
            })
            
           
        });
    });
    


</script>


<!-- buat list dropdown jenis tabungan -->
<?php

        $idUser = $_SESSION["id"];
        $categories = mysqli_fetch_all(mysqli_query($link, "SELECT namaAset from aset where idUser = $idUser"), MYSQLI_ASSOC);
        $count = 0;
        foreach($categories as $item) {
            $category[$count] = $item['namaAset'];
            $count++;
        }
?>

<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>


</html>

<?php include 'inc/footer.php'; ?>