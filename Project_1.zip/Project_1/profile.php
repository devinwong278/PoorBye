<?php include 'inc/header.php'; ?>

<?php 

  // $nama_lengkap  
  
  if($_SERVER["REQUEST_METHOD"] == "POST") {
    $idUser = $_SESSION["id"];
    // var_dump($_SESSION);
    

  $namaLengkap = $_POST["name"];
  $tempatLahir = $_POST["tempatLahir"];
  $tanggalLahir = $_POST["tanggalLahir"];
  $nomorTelepon = $_POST["nomorTelepon"];
  $alamat = $_POST["alamat"];
  $email = $_POST["email"];
  if(isset($_POST["agama"])) $agama = $_POST["agama"];
  else
    $agama = "";

  if(isset($_POST["pendidikan"])) $pendidikan = $_POST["pendidikan"];
  else
    $pendidikan = "";

  if(isset($_POST["pekerjaan"])) $pekerjaan = $_POST["pekerjaan"];
  else
    $pekerjaan = "";


  // echo " ", $namaLengkap;
  // echo " ", $tempatLahir;
  // echo " ", $tanggalLahir;
  // echo " ", $nomorTelepon;
  // echo " ", $alamat;
  // echo " ", $email;
  // echo " ", $agama;
  // echo " ", $pendidikan;
  // echo " ", $pekerjaan;

  // var_dump($namaLengkap);

  $sql = "UPDATE `user` 
  SET `idAgama`= $agama,
  `idPekerjaan`= $pekerjaan,
  `idPendidikan`= $pendidikan,
  `namaLengkap`= '$namaLengkap',
  `email`= '$email',
  `alamat`= '$alamat',
  `noHP`= '$nomorTelepon',
  `tglLahir`= '$tanggalLahir',
  `tempat_lahir`= '$tempatLahir'
  WHERE idUser = $idUser";

  $_SESSION["name"] = $namaLengkap;
  $link->query($sql);


//   if ($link->query($sql) === TRUE) {
//   echo "Record updated successfully";
// } else {
//   echo "Error deleting record: " . $link->error;
// }

  }

?>

<?php

$idUser = $_SESSION['id'];

$data_user = mysqli_fetch_all(mysqli_query($link, "SELECT 
*,
date_format(tglLahir, '%d %M %Y') as 'tglLahirF'
FROM `user` 
WHERE idUser = $idUser"))[0];
// var_dump($data_user);


$data_agama = mysqli_fetch_all(mysqli_query($link, "SELECT a.namaAgama
from `user` u join agama a on u.idAgama = a.id
where idUser = $idUser"));
// var_dump($data_agama);

$data_pekerjaan = mysqli_fetch_all(mysqli_query($link, "SELECT p.namaPekerjaan
from `user` u join pekerjaan p on u.idPekerjaan = p.id
where idUser = $idUser"));
// var_dump($data_pekerjaan);

$data_pendidikan = mysqli_fetch_all(mysqli_query($link, "SELECT p.namaPendidikan
from `user` u join pendidikan p on u.idPendidikan = p.id
where idUser = $idUser"));

$agama = mysqli_fetch_all(mysqli_query($link, "SELECT * FROM `agama`"));

$pendidikan = mysqli_fetch_all(mysqli_query($link, "SELECT * FROM `pendidikan`"));

$pekerjaan = mysqli_fetch_all(mysqli_query($link, "SELECT * FROM `pekerjaan` "));

// var_dump($data_user[9]);


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />
  </head>
  <link rel="stylesheet" href="css/profileCSS.css" />
  <body>

  <div id="body"></div>

  <!-- body sign up -->
  <div class="signUp" id="signUp_box">
      
      <div id="signUp2">
        <div class="isi2">
          <div class="boxluar" >
            <div id="judul">Edit Profile</div>

            <div class="formBox" id="formBox">
              <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" id="form">
                <label class="label2" for="name">Nama Lengkap:</label>
                <input type="text" name="name" id="form_name" autocomplete="off" required/>

                <label class="label2" for="email">Tempat Lahir:</label>
                <input type="text" name="tempatLahir" id="form_tempatLahir" autocomplete="off" required/>

                <label class="label2" for="email">Tanggal Lahir:</label>
                <input type="date" name="tanggalLahir" id="form_tanggalLahir" autocomplete="off" required/>
                
                <label class="label2" for="email">Alamat:</label>
                <input type="text" name="alamat" id="form_alamat" autocomplete="off" required/>
                
                <label class="label2" for="">Agama:</label>
                <select name="agama" id="form_agama" required>
                  <?php foreach($agama as $item): ?>
                    <option value="<?php echo $item[0];?>"><?php echo $item[1] ;?></option>
                  <?php endforeach; ?>
                </select>
                
                <label class="label2" for="">Pendidikan Terakhir:</label>
                <select name="pendidikan" id="form_pendidikan" required>
                  <?php foreach($pendidikan as $item): ?>
                    <option value="<?php echo $item[0];?>"><?php echo $item[1] ;?></option>
                  <?php endforeach; ?>
                  
                </select>
                
                <label class="label2" for="">Pekerjaan:</label>
                <select name="pekerjaan" id="form_pekerjaan" required>
    
                  <?php foreach($pekerjaan as $item): ?>
                    <option value="<?php echo $item[0];?>"><?php echo $item[1] ;?></option>
                  <?php endforeach; ?>
                  
                </select>

                <label class="label2" for="nomorTelepon">Nomor Telepon: </label>
                <input type="text" name="nomorTelepon" id="form_nomorTelepon" autocomplete="off" required/>

                <label class="label2" for="email">Email:  </label>
                <input type="text" name="email" id="form_email" autocomplete="off" required/>

                <input type="submit" id="submit" value="Save" onclick="return confirm('yakin update?')">
                <button type="button" id="cancel">Cancel</button>

              </form>
          
            </div>
          </div>
        </div>
      </div>
     
    </div>
    <!-- body sign up -->




    <!-- Awal profile -->
    <div class="profile">
      <div class="profile_box">
        <p>PROFILE </p>
      <button id="button_edit"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
  <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
</svg> edit</button>
      </div>
    </div>
    <div class="biodata">
      <div class="data" id="nama_lengkap">
        <h2> Nama Lengkap</h2>
        <h1><?php echo $data_user[4]; ?></h1>
      </div>
      <div class="data" id="tempatLahir">
        <h2> Tempat Lahir</h2>
        <h1><?php echo (!isset($data_user[10])) ? "-" : $data_user[10]; ?></h1>
      </div>
      <div class="data" id="TanggalLahir">
        <h2> Tanggal Lahir</h2>
        <h1><?php echo (!isset($data_user[9])) ? "-" : $data_user[11]; ?></h1>
      </div>
      <div class="data" id="alamat">
        <h2> Alamat</h2>
        <h1><?php echo (!isset($data_user[7])) ? "-" : $data_user[7]; ?></h1>
      </div>
      <div class="data" id="agama">
        <h2> Agama</h2>
        <h1><?php echo (!isset($data_user[1])) ? "-" : $data_agama[0][0]; ?></h1>
      </div>
      <div class="data" id="pendidikan terakhir">
        <h2> Pendidikan Terakhir</h2>
        <h1><?php echo (!isset($data_user[3])) ? "-" : $data_pendidikan[0][0]; ?></h1>
      </div>
      <div class="data" id="pekerjaan">
        <h2> Pekerjaan</h2>
        <h1><?php echo (!isset($data_user[2])) ? "-" : $data_pekerjaan[0][0]; ?></h1>
      </div>
      <div class="data" id="nomor_hp">
        <h2> Nomor Telepon</h2>
        <h1><?php echo (!isset($data_user[8])) ? "-" : $data_user[8]; ?></h1>
      </div>
      <div class="dataEmail" id="dataEmail">
        <h2> Email</h2>
        <h1><?php echo (!isset($data_user[5])) ? "-" : $data_user[5]; ?></h1>
      </div>
    </div>
    <div class="profile">
      <p>INFORMASI</p>
    </div>

    <div class="informasi">
      <div class="info">
        <a href="">
          <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M128 64C128 80.9739 121.257 97.2525 109.255 109.255C97.2525 121.257 80.9739 128 64 128C47.0261 128 30.7475 121.257 18.7452 109.255C6.74284 97.2525 0 80.9739 0 64C0 47.0261 6.74284 30.7475 18.7452 18.7452C30.7475 6.74284 47.0261 0 64 0C80.9739 0 97.2525 6.74284 109.255 18.7452C121.257 30.7475 128 47.0261 128 64ZM43.968 48.264H50.568C51.672 48.264 52.552 47.36 52.696 46.264C53.416 41.016 57.016 37.192 63.432 37.192C68.92 37.192 73.944 39.936 73.944 46.536C73.944 51.616 70.952 53.952 66.224 57.504C60.84 61.416 56.576 65.984 56.88 73.4L56.904 75.136C56.9124 75.6609 57.1268 76.1614 57.501 76.5296C57.8751 76.8978 58.3791 77.1041 58.904 77.104H65.392C65.9224 77.104 66.4311 76.8933 66.8062 76.5182C67.1813 76.1431 67.392 75.6344 67.392 75.104V74.264C67.392 68.52 69.576 66.848 75.472 62.376C80.344 58.672 85.424 54.56 85.424 45.928C85.424 33.84 75.216 28 64.04 28C53.904 28 42.8 32.72 42.04 46.288C42.029 46.5463 42.0711 46.8042 42.1635 47.0457C42.2558 47.2872 42.3967 47.5073 42.5772 47.6924C42.7578 47.8775 42.9744 48.0237 43.2135 48.122C43.4527 48.2203 43.7095 48.2686 43.968 48.264ZM62.568 99.808C67.448 99.808 70.8 96.656 70.8 92.392C70.8 87.976 67.44 84.872 62.568 84.872C57.896 84.872 54.496 87.976 54.496 92.392C54.496 96.656 57.896 99.808 62.576 99.808H62.568Z"
              fill="#59606D"
            />
          </svg>
          <p>FAQ</p>
        </a>
      </div>
      <div id="infoTengah" class="info">
        <a href="aboutus.php">
          <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M64 0C28.7104 0 0 28.7104 0 64C0 99.2896 28.7104 128 64 128C99.2896 128 128 99.2896 128 64C128 28.7104 99.2896 0 64 0ZM64 26.24C65.6455 26.24 67.2541 26.728 68.6223 27.6422C69.9906 28.5564 71.057 29.8558 71.6867 31.3761C72.3164 32.8964 72.4812 34.5692 72.1601 36.1831C71.8391 37.7971 71.0467 39.2796 69.8831 40.4431C68.7196 41.6067 67.2371 42.3991 65.6232 42.7201C64.0092 43.0412 62.3364 42.8764 60.8161 42.2467C59.2958 41.617 57.9964 40.5506 57.0822 39.1823C56.168 37.8141 55.68 36.2055 55.68 34.56C55.68 32.3534 56.5566 30.2372 58.1169 28.6769C59.6772 27.1166 61.7934 26.24 64 26.24ZM79.36 98.56H51.2C49.8421 98.56 48.5398 98.0206 47.5796 97.0604C46.6194 96.1002 46.08 94.7979 46.08 93.44C46.08 92.0821 46.6194 90.7798 47.5796 89.8196C48.5398 88.8594 49.8421 88.32 51.2 88.32H60.16V60.16H55.04C53.6821 60.16 52.3798 59.6206 51.4196 58.6604C50.4594 57.7002 49.92 56.3979 49.92 55.04C49.92 53.6821 50.4594 52.3798 51.4196 51.4196C52.3798 50.4594 53.6821 49.92 55.04 49.92H65.28C66.6379 49.92 67.9402 50.4594 68.9004 51.4196C69.8606 52.3798 70.4 53.6821 70.4 55.04V88.32H79.36C80.7179 88.32 82.0202 88.8594 82.9804 89.8196C83.9406 90.7798 84.48 92.0821 84.48 93.44C84.48 94.7979 83.9406 96.1002 82.9804 97.0604C82.0202 98.0206 80.7179 98.56 79.36 98.56Z"
              fill="#59606D"
            />
          </svg>
          <p>ABOUT US</p>
        </a>
      </div>
      <div class="infoTC">
        <a href="">
          <svg width="95" height="128" viewBox="0 0 95 128" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M25.1107 16C28.3516 6.675 37.1589 0 47.5 0C57.8411 0 66.6484 6.675 69.8893 16H79.1667C87.8997 16 95 23.175 95 32V112C95 120.825 87.8997 128 79.1667 128H15.8333C7.10026 128 0 120.825 0 112V32C0 23.175 7.10026 16 15.8333 16H25.1107ZM55.4167 24C55.4167 19.575 51.8789 16 47.5 16C43.1211 16 39.5833 19.575 39.5833 24C39.5833 28.425 43.1211 32 47.5 32C51.8789 32 55.4167 28.425 55.4167 24ZM39.5833 92C39.5833 94.2 41.3646 96 43.5417 96H75.2083C77.3854 96 79.1667 94.2 79.1667 92C79.1667 89.8 77.3854 88 75.2083 88H43.5417C41.3646 88 39.5833 89.8 39.5833 92ZM23.75 98C27.0404 98 29.6875 95.325 29.6875 92C29.6875 88.675 27.0404 86 23.75 86C20.4596 86 17.8125 88.675 17.8125 92C17.8125 95.325 20.4596 98 23.75 98ZM39.5833 68C39.5833 70.2 41.3646 72 43.5417 72H75.2083C77.3854 72 79.1667 70.2 79.1667 68C79.1667 65.8 77.3854 64 75.2083 64H43.5417C41.3646 64 39.5833 65.8 39.5833 68ZM23.75 74C27.0404 74 29.6875 71.325 29.6875 68C29.6875 64.675 27.0404 62 23.75 62C20.4596 62 17.8125 64.675 17.8125 68C17.8125 71.325 20.4596 74 23.75 74Z"
              fill="#59606D"
            />
          </svg>
          <p>TERM AND CONDITION</p>
        </a>
      </div>
    </div>

    <div class="profile">
      <p>AKUN</p>
    </div>

    <div class="informasi">
      <div class="info">
        <a href="logout.php">
          <svg width="116" height="128" viewBox="0 0 116 128" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M12.8 0H70.4C73.7948 0 77.0505 1.34857 79.451 3.74903C81.8514 6.1495 83.2 9.40523 83.2 12.8V19.2C83.2 20.8974 82.5257 22.5252 81.3255 23.7255C80.1253 24.9257 78.4974 25.6 76.8 25.6C75.1026 25.6 73.4748 24.9257 72.2745 23.7255C71.0743 22.5252 70.4 20.8974 70.4 19.2V12.8H12.8V115.2H70.4V108.8C70.4 107.103 71.0743 105.475 72.2745 104.275C73.4748 103.074 75.1026 102.4 76.8 102.4C78.4974 102.4 80.1253 103.074 81.3255 104.275C82.5257 105.475 83.2 107.103 83.2 108.8V115.2C83.2 118.595 81.8514 121.851 79.451 124.251C77.0505 126.651 73.7948 128 70.4 128H12.8C9.40523 128 6.1495 126.651 3.74903 124.251C1.34857 121.851 0 118.595 0 115.2V12.8C0 9.40523 1.34857 6.1495 3.74903 3.74903C6.1495 1.34857 9.40523 0 12.8 0Z"
              fill="#59606D"
            />
            <path
              d="M81.8878 91.4881C84.3838 93.9841 88.4158 93.9841 90.9118 91.4881L113.875 68.5249C115.075 67.3247 115.749 65.6972 115.749 64.0001C115.749 62.3031 115.075 60.6755 113.875 59.4753L90.9118 36.5121C89.6952 35.4126 88.1026 34.8225 86.4633 34.8639C84.824 34.9052 83.2632 35.5749 82.1037 36.7345C80.9442 37.894 80.2745 39.4548 80.2331 41.0941C80.1917 42.7334 80.7818 44.3259 81.8814 45.5425L93.8878 57.6001H38.3998C36.7024 57.6001 35.0745 58.2744 33.8743 59.4746C32.674 60.6749 31.9998 62.3027 31.9998 64.0001C31.9998 65.6975 32.674 67.3254 33.8743 68.5256C35.0745 69.7258 36.7024 70.4001 38.3998 70.4001H93.8878L81.8814 82.4577C80.6867 83.6571 80.0165 85.2814 80.0177 86.9742C80.0189 88.6671 80.6914 90.2904 81.8878 91.4881Z"
              fill="#59606D"
            />
          </svg>
          <p>LOG OUT</p>
        </a>
      </div>
      <div id="infoLeft" class="info">
        <a href="">
          <svg width="127" height="128" viewBox="0 0 127 128" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M119.984 3.1602L123.457 6.63287C128.242 11.424 127.518 19.9173 121.826 25.6031L50.2126 97.2168L27.0104 105.704C24.0968 106.775 21.2598 105.386 20.683 102.614C20.4881 101.609 20.5799 100.568 20.9479 99.6123L29.6002 76.21L101.014 4.79059C106.705 -0.895186 115.199 -1.62504 119.984 3.16608V3.1602ZM47.0871 10.2821C47.8601 10.2821 48.6255 10.4344 49.3396 10.7302C50.0537 11.026 50.7025 11.4595 51.2491 12.0061C51.7957 12.5526 52.2292 13.2015 52.525 13.9156C52.8208 14.6297 52.973 15.3951 52.973 16.168C52.973 16.941 52.8208 17.7063 52.525 18.4205C52.2292 19.1346 51.7957 19.7834 51.2491 20.33C50.7025 20.8765 50.0537 21.3101 49.3396 21.6059C48.6255 21.9017 47.8601 22.0539 47.0871 22.0539H23.5436C20.4215 22.0539 17.4273 23.2942 15.2197 25.5018C13.012 27.7094 11.7718 30.7036 11.7718 33.8257V104.456C11.7718 107.578 13.012 110.573 15.2197 112.78C17.4273 114.988 20.4215 116.228 23.5436 116.228H94.1743C97.2964 116.228 100.291 114.988 102.498 112.78C104.706 110.573 105.946 107.578 105.946 104.456V80.9128C105.946 79.3518 106.566 77.8547 107.67 76.7509C108.774 75.6471 110.271 75.027 111.832 75.027C113.393 75.027 114.89 75.6471 115.994 76.7509C117.098 77.8547 117.718 79.3518 117.718 80.9128V104.456C117.718 110.701 115.237 116.689 110.822 121.104C106.407 125.52 100.418 128 94.1743 128H23.5436C17.2994 128 11.311 125.52 6.89575 121.104C2.48048 116.689 0 110.701 0 104.456V33.8257C0 27.5816 2.48048 21.5932 6.89575 17.1779C11.311 12.7626 17.2994 10.2821 23.5436 10.2821H47.0871Z"
              fill="#59606D"
            />
          </svg>
          <p>SIGN UP</p>
        </a>
      </div>
    </div>

    <!-- akhir profile -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  
    <script>
      console.log("mulai");

      var body = document.getElementById("body");
      // // console.log(body)


      var button_edit = document.getElementById('button_edit');
      var signup_box = document.getElementById('signUp_box');
      var form = document.getElementById('formBox');
      button_edit.onclick = function() {
        console.log("halo")
        signup_box.classList.add('signUp_box_active');
        document.body.classList.add('disable-scroll');
        body.classList.add('dark-mode');
        form.classList.add('enable-scroll');
      }
      
      var button_cancel = document.getElementById('cancel')
      button_cancel.onclick = function() {
        signup_box.classList.remove('signUp_box_active');
        document.body.classList.remove('disable-scroll');
        body.classList.remove('dark-mode');
      }
      
      setInterval(() => {
        if(form.classList.contains('enable-scroll')) {
          // console.log("halo")
          // console.log(form);
          body.onclick = function() {
            // console.log("hi")
            signup_box.classList.remove('signUp_box_active');
            form.classList.remove('enable-scroll');
            // console.log(form);
            document.body.classList.remove('disable-scroll');
            body.classList.remove('dark-mode');
          }
      } else {
        document.body.onclick = function() {

        }
      }
    }, 100)
      
      
      
      // FORM START 
      var namaLengkap = document.getElementById('form_name');
      var tempatLahir = document.getElementById('form_tempatLahir');
      var tanggalLahir = document.getElementById('form_tanggalLahir');
      var alamat = document.getElementById('form_alamat');
      var agama = document.getElementById('form_agama');
      var pendidikan = document.getElementById('form_pendidikan');
      var pekerjaan = document.getElementById('form_pekerjaan');
      var nomorTelepon = document.getElementById('form_nomorTelepon');
      var email = document.getElementById('form_email');

      var value_pendidikan = <?php echo json_encode($data_user[3]); ?>;
      console.log(value_pendidikan);

      
      namaLengkap.value = <?php if(isset($data_user[4])) {
        echo json_encode($data_user[4]);
      } ?>;

      // tempatLahir.value = <?php echo (isset($data_user[10])) ? "''" : $data_user[10]; ?>;
      
      tempatLahir.value = <?php if(isset($data_user[10])) echo json_encode($data_user[10]); 
      else 
      echo "''";
      ?>;

      tanggalLahir.value = <?php if(isset($data_user[9])) echo json_encode($data_user[9]); 
      else 
      echo "''";
      ?>;
      

      alamat.value = <?php if (isset($data_user[7])) {
        echo json_encode($data_user[7]);
      } else 
      echo "''";
      ?>;

      agama.selectedIndex = '<?php if(isset($data_user[1])) echo $data_user[1]-1;
      else
        echo "-1";
      ?>';
      // console.log(agama.value);

      pendidikan.selectedIndex = '<?php if (isset($data_user[3]))
        echo $data_user[3] - 1;
      else
        echo "-1"; ?>';

      pekerjaan.selectedIndex = '<?php if(isset($data_user[2]))
        echo $data_user[2] - 1; 
      else
        echo "-1"; ?>';

      nomorTelepon.value = <?php if(isset($data_user[8])) { echo json_encode($data_user[8]);
      } else 
      echo "''";
      ?>;

      email.value = <?php if(isset($data_user[5])) { 
        echo json_encode($data_user[5]);
      } ?>;


    </script>
  </body>



  

</html>

<?php include 'inc/footer.php'; ?>