<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>

<?php

extract($_POST);

// var_dump($_POST);


$value_range = $_POST["value_range"];
// var_dump($value_range);

if($value_range == "Harian") {
    $idUser = $_SESSION["id"];

    $input_bulan = $_POST["input_bulan"];
    $input_tahun = $_POST["input_tahun"];  

    // echo "halooo";
    $graph = mysqli_fetch_all(mysqli_query($link, "SELECT sum(nominal), day(tglTransaksi) 
    from transaksi where idUser = $idUser AND idJenisTransaksi = 2 AND month(tglTransaksi) = $input_bulan AND year(tglTransaksi) = $input_tahun 
    group by tglTransaksi"), MYSQLI_ASSOC);
    
    $maxY_graph = mysqli_fetch_all(mysqli_query($link, "SELECT max(sn)
    from (SELECT sum(nominal) as sn, day(tglTransaksi) from transaksi where idUser = $idUser AND idJenisTransaksi = 2 group by tglTransaksi) as t"), MYSQLI_ASSOC);
    $maxX_graph = mysqli_fetch_all(mysqli_query($link, 'SELECT max(day(`tglTransaksi`)) from transaksi'), MYSQLI_ASSOC);

$maxY_js = $maxY_graph[0]['max(sn)'];
$maxX_js = $maxX_graph[0]['max(day(`tglTransaksi`))'];

$yarr = [];
$xarr = [];

    $count = 0;
    foreach($graph as $item) {

        $yarr[$count] = $item['sum(nominal)'];
        $xarr[$count] = $item['day(tglTransaksi)'];
        $count++;

    }
    $count = 0;

$row_nums = count($graph);

} else if($value_range == "Bulanan") {

    $idUser = $_SESSION["id"];
    $input_tahun = $_POST["input_tahun"];
    $input_bulan = "";

    // var_dump($input_tahun);
    
    $graph = mysqli_fetch_all(mysqli_query($link, "SELECT sum(nominal), month(tglTransaksi) 
    from transaksi where idUser = $idUser AND idJenisTransaksi = 2 AND year(tglTransaksi) = $input_tahun 
    group by month(tglTransaksi)"), MYSQLI_ASSOC);
    
    $maxY_graph = mysqli_fetch_all(mysqli_query($link, "SELECT max(sn)
    from (SELECT sum(nominal) as sn, day(tglTransaksi) from transaksi where idUser = $idUser AND idJenisTransaksi = 2 group by month(tglTransaksi)) as t"), MYSQLI_ASSOC);
    // $maxX_graph = mysqli_fetch_all(mysqli_query($link, 'SELECT max(month(`tglTransaksi`)) from transaksi'), MYSQLI_ASSOC);

$maxY_js = $maxY_graph[0]['max(sn)'];
$maxX_js = 13.5;

$yarr = [];
$xarr = [];

    $count = 0;
    foreach($graph as $item) {

        $yarr[$count] = $item['sum(nominal)'];
        $xarr[$count] = $item['month(tglTransaksi)'];
        $count++;

    }
    $count = 0;

$row_nums = count($graph);
}



?>

<!DOCTYPE html>
<html lang="en-US">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Today's Date</title>
</head>
 
<body>
 
<div id="myPlot" style="width:100%;"></div>

<script>

        var yArray = <?php echo json_encode($yarr) ?>;
        var xArray = <?php echo json_encode($xarr) ?>;
        var maxY = <?php echo json_encode($maxY_js) ?>;
        var maxX = <?php echo json_encode($maxX_js) ?>;
        var input_bulan = <?php echo json_encode($input_bulan) ?>;
        var input_tahun = <?php echo json_encode($input_tahun) ?>;
        var row_nums = <?php echo json_encode($row_nums) ?>;
        console.log("hi" + row_nums);

        // console.log(yArray);

        if(row_nums == 0) {
            var boxgambarstatistic = document.getElementById("boxgambarstatistic");
            console.log(boxgambarstatistic);
            boxgambarstatistic.innerHTML = "No transaction";
        } else {
            // Define Data
            var trace1 = {
                x: xArray,
                y: yArray,
                type: "bar",
                line: {
                    color: 'rgb(90, 210, 102)',
                    width: 5
                }
            };
            var trace2 = {
                x: xArray,
                y: yArray,
                // yaxis: 'y2',
                type: "line",
                line: {
                    color: 'rgb(90, 210, 102)',
                    width: 5
                }
            };

            var data = [trace1, trace2];

            // Define Layout
            var layout = {
                xaxis: {range: [0, maxX], title: "Date"},
                yaxis: {range: [0, maxY], title: "Nominal"}, 
                // yaxis2: {range: [0, maxY], title: "Nominal"}, 
                title: transform_month(input_bulan) + " " + input_tahun,
                showlegend: false
                
            };

            // Display using Plotly
            Plotly.newPlot("myPlot", data, layout);

            function transform_month(i) { 
                if(i == 1) return 'January'
                else if (i == 2) return 'February'
                else if (i == 3) return 'March'
                else if (i == 4) return 'April'
                else if (i == 5) return 'May'
                else if (i == 6) return 'June'
                else if (i == 7) return 'July'
                else if (i == 8) return 'August'
                else if (i == 9) return 'September'
                else if (i == 10) return 'October'
                else if (i == 11) return 'November'
                else if (i == 12) return 'December'
            }
        }
</script>




</body>
 
</html>