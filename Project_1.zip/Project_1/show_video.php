<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>

<?php

extract($_POST);

$idUser = $_SESSION["id"];

$idTopic = $_POST["idTopic"];

$videoLink = mysqli_fetch_all(mysqli_query($link, "SELECT *
FROM topic
WHERE idTopic = $idTopic;"), MYSQLI_ASSOC)[0]['videoLink'];

var_dump($videoLink);



?>

<!DOCTYPE html>
<html lang="en-US">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Today's Date</title>
</head>
 
<body>
 
<div id="showVideo" >
    <iframe id="iframe" src="" frameborder="0"></iframe>
    <?php echo $videoLink; ?>;
</div>

<script>
    var videoLink = <?php json_encode($videoLink); ?>;
    

    var iframe = document.getElementById("iframe");
    // iframe.src = videoLink;
    console.log(iframe);

    $(document).ready(function() {
          $.ajax({
            url: 'course_detail.php',
            data: {videoLink: videoLink},
            method: 'POST',
            success: function(html) {
              var $this = $(this);
            }
          })
        })

</script>




</body>
 
</html>