$(document).ready(function () {
    $('#search').on('keyup', function () {
        if ($('#search').val() == '') {
            document.location.reload();
            // $('.course_list').load('searchDefault.php');
        } else {
            $('.course_list').load('searchResult.php?keyword=' + $('#search').val());
            console.log($('#search').val());
            
        }
    })
})