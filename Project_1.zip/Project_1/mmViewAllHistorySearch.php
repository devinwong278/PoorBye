<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>


<?php

extract($_POST);

$category = $_POST['value_category'];
$date = $_POST['value_date'];

// var_dump($date);

$idUser = $_SESSION["id"];

if(empty($date) ) {
    $date = "SELECT tglTransaksi from transaksi where idUser = $idUser";
} else {
    $date = "'$date'";
}

if($category == "all" ) {
    $category = "SELECT namaAset from aset where idUser = $idUser";
} else {
    $category = "'$category'";
}

    // var_dump($date);
    // var_dump($category);

// buat bikin table history
  $result = mysqli_query($link, "SELECT 
            *,
            day(t.tglTransaksi),
            t.nominal
            from transaksi t
            where idUser = $idUser");
      // $table_history = mysqli_fetch_all($result , MYSQLI_ASSOC);

  $data_count = mysqli_num_rows($result);
  $data_per_page = 8;
  $page_count = ceil($data_count / $data_per_page);
  if(isset($_GET["page"])) {
    $active_page = $_GET["page"];
  } else {
  $active_page = 1;
  }

  $first_data = ($active_page - 1) * $data_per_page;

// var_dump($first_data);
    
  $table_history = mysqli_fetch_all(mysqli_query($link, "SELECT 
  *,
  day(t.tglTransaksi),
  t.nominal,
  format(t.nominal, 0) as 'nominalF',
  date_format(t.tglTransaksi, '%m/%d/%Y') as 'tglTransaksiF'
  from transaksi t join aset a on t.idAset = a.idAset
  WHERE t.idUser = $idUser and namaAset in ($category) and tglTransaksi in ($date)  
  ORDER BY t.tglTransaksi DESC, idTransaksi ASC
  LIMIT $first_data, $data_per_page"), MYSQLI_ASSOC);

// var_dump($table_history);
$namaAset = mysqli_fetch_all(mysqli_query($link, "SELECT namaAset FROM aset WHERE idUser = $idUser"));

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MM - View All History</title>
    <link rel="shortcut icon" href="/logo.png" type="image/x-icon" />
    <link href="css/mmViewAllHistory.css" rel="stylesheet" />
    <style>
        #tbody {
            width: 100%;
        }
    </style>
  </head>
  <body>
 
    <table>
      <tbody id="tbody">
            <?php $id = 1  ; ?> 
            <?php foreach($table_history as $item): ?>
                <tr>
                    <td style="text-align:left; padding: 10px;"><?php echo $item['namaTransaksi'] ? $item['namaTransaksi'] : '-'; ?></td>
                    <td style="text-align:center; padding-left: 50px; padding-right: 50px;color: <?php echo ($item['idJenisTransaksi'] == "1") ? "green" : "red"; ?>;"><?php echo ($item['idJenisTransaksi'] == "1" ? "+" : "-") . "Rp" . $item['nominalF']; ?></td>
                    <td style="text-align:center; padding-left: 50px; padding-right: 50px;"><?php echo $item['namaAset']; ?></td>
                    <td style="text-align:right; padding-left: 50px; padding-right: 50px;"><?php echo $item['tglTransaksiF']; ?></td>
                </tr>
                <?php $id++; ?>
            <?php endforeach; ?>
          </tbody>
            <?php if($id == 1): ?>
              <p id="error_message">No transaction</p>
            <?php endif; ?>
        </table>

  
        
  </body>

</html>
