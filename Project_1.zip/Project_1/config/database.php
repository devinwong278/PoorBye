<?php 
define('DB_HOST', 'localhost');
define('DB_USER', 'dev');
define('DB_PASS', 'devin2782002');
define('DB_NAME', 'test_poorbye2');

// create connection
$link = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

//check connection
if($link->connect_error) {
    die('Connection failed ' . $link->connect_error);
}
