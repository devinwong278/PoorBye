<?php include 'inc/header.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Money Management - PoorBye</title>
    <link rel="stylesheet" href="css/add_transaction_alokasi.css">
</head>
<body>  
    <div class="batas"> 
        <div class="boxluar">
            <div class="judul">Alokasi Baru</div>
            <div class="pilihan">
                <div class="pemasukan-container">
                    <a href="add_transaction_pemasukan.php" style="text-decoration: none">Pemasukan</a>
                </div>
                <div class="alokasi-container">
                    <a href="add_transaction_alokasi.php" style="text-decoration: none">Alokasi</a>
                </div>
                <div class="pengeluaran-container">
                    <a href="add_transaction_pengeluaran.php" style="text-decoration: none">Pengeluaran</a>
                </div>
            </div>
            <div class="datainput-container">
                <div class="datainput">
                    <form action="add_transaction_alokasi.php" method="post" id="datainput" name="form">
                        
                        <div class="container1">
                            <label for="nominal">Nominal</label><br>
                            <div class="form-input1">
                                <input type="text" id="text1" class="text1" name="nominal">
                                <p class="static-value">Rp</p>
                            </div>
                        </div>
                        
                        <div class="form-input-container">
                            <div class="container1">
                                <div class="containerAsalTujuan">
                                    <div class="form-input2">
                                        <label for="Kategori">Asal</label><br>
                                        <select id="program" name="category_source">

                                        </select>
                                    </div>
                                    <div class="form-input2">
                                        <label for="Kategori">Tujuan</label><br>
                                        <select id="program2" name="category_destination">
                                        
                                        </select>
                                    </div>

                                </div>
                            </div>

                            <div class="container1">
                                <div class="tanggal">
                                    <div class="gambardiv">
                                        <img class="gambar-kalender" src="ASSETS/calendar 1.png">
                                    </div>
                                    <div class="datediv">
                                        <input type="date" class="date" name="date">
                                    </div>
                                </div>
                            </div>
                            <h3 class="judul-opsional">Informasi Opsional</h3>

                            <div class="container2">
                                <div class="opsional">
                                    <p class="nama-transaksi">Nama Transaksi</p>
                                    <input type="text" class="opsional-input" value="-" name="namaTransaksi">
                                </div>
                            </div>

                             <div class="simpantransaksi-container">
                                <input type="submit" value="Simpan Transaksi" id="simpan-transaksi">
                            </div>
                        </div>

                    </form>
                </div>
               
            </div>

        </div>
    </div>
</body>
</html>

<?php

        $idUser = $_SESSION["id"];
        $categories = mysqli_fetch_all(mysqli_query($link, "SELECT namaAset from aset where idUser = $idUser"), MYSQLI_ASSOC);
        $count = 0;
        foreach($categories as $item) {
            $category[$count] = $item['namaAset'];
            $count++;
        }
?>

<script>
    var category = <?php echo json_encode($category); ?>;
    var category2 = <?php echo json_encode($category); ?>;

    var element2 = document.getElementById("program"); //sumber
    console.log(element2);
    var element3 = document.getElementById("program2"); //tujuan
    var value_source;
        
    
    element2.onclick = function() {
        element3.options.length = 0;
        value_source = element2.value;

        category2.forEach(element => {
        var para2 = document.createElement("option");
            var node2 = document.createTextNode(element);
            para2.appendChild(node2);
            if(element != value_source) {
                element3.appendChild(para2);
            }
        });
    }

    // default asal
    category.forEach(element => {
        var para2 = document.createElement("option");
            var node2 = document.createTextNode(element);
            para2.appendChild(node2);
            element2.appendChild(para2);

    });

    // default tujuan
    value_source = element2.value;
    category2.forEach(element => {
        var para2 = document.createElement("option");
        var node2 = document.createTextNode(element);
        para2.appendChild(node2);
        if(element != value_source) {
            element3.appendChild(para2);
        }
    });


    
        
</script>


<?php

$nominal = $date = "";

if($_SERVER["REQUEST_METHOD"] == "POST") {
    

    // kurangin dari source

    $nominal = trim($_POST["nominal"]);
    $date = trim($_POST["date"]);
    $kategori_source = trim($_POST["category_source"]);
    echo $idUser;
    // $categories = mysqli_fetch_all(mysqli_query($link, "SELECT namaAset from aset where idUser = $idUser"), MYSQLI_ASSOC);
    $aset_source = mysqli_fetch_all(mysqli_query($link, "SELECT idAset from aset where idUser = $idUser and namaAset = '$kategori_source'"), MYSQLI_ASSOC);
    print_r($aset_source);
    $idAset = $aset_source[0]['idAset'];
    echo $idAset;
    $namaTransaksi = trim($_POST["namaTransaksi"]);
    
    $sql = "INSERT INTO transaksi (idUser, idJenisTransaksi, idAset, nominal, `tglTransaksi`, namaTransaksi) VALUES ($idUser, 2, ?, ?, ?, ?)";
    $sql2 = "UPDATE `aset` SET nominal = nominal - $nominal where idUser = $idUser and namaAset = '$kategori_source'";
    $link->query($sql2);
    
    if($stmt = mysqli_prepare($link, $sql)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "iiss", $param_idAset, $param_nominal, $param_date, $param_namaTransaksi);
        
        // Set parameters
        $param_idAset = $idAset;
        $param_nominal = $nominal;
        $param_date = $date;
        $param_namaTransaksi = $namaTransaksi; // Creates a password hash
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // Redirect to login page
            // header("location: welcome.php");
            // echo "nice";     
        } else{
            echo "Oops! Something went wrong. Please try again later.";
            echo "Error: " . $sql . "<br>" . $link->error;
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }


    // tambahin ke destination
    

    $kategori_destination = trim($_POST["category_destination"]);
    echo $idUser;
    // $categories = mysqli_fetch_all(mysqli_query($link, "SELECT namaAset from aset where idUser = $idUser"), MYSQLI_ASSOC);
    $aset_destination = mysqli_fetch_all(mysqli_query($link, "SELECT idAset from aset where idUser = $idUser and namaAset = '$kategori_destination'"), MYSQLI_ASSOC);
    print_r($aset_destination);
    $idAset = $aset_destination[0]['idAset'];
    echo $idAset;
    $namaTransaksi = trim($_POST["namaTransaksi"]);
    
    $sql3 = "INSERT INTO transaksi (idUser, idJenisTransaksi, idAset, nominal, `tglTransaksi`, namaTransaksi) VALUES ($idUser, 1, ?, ?, ?, ?)";
    $sql4 = "UPDATE `aset` SET nominal = nominal + $nominal where idUser = $idUser and namaAset = '$kategori_destination'";
    $link->query($sql4);

    if($stmt2 = mysqli_prepare($link, $sql3)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt2, "iiss", $param_idAset, $param_nominal, $param_date, $param_namaTransaksi);
        
        // Set parameters
        $param_idAset = $idAset;
        $param_nominal = $nominal;
        $param_date = $date;
        $param_namaTransaksi = $namaTransaksi; // Creates a password hash
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt2)){
            // Redirect to login page
            header("location: mmFront.php");
            // echo "nice";     
        } else{
            echo "Oops! Something went wrong. Please try again later.";
            echo "Error: " . $sql3 . "<br>" . $link->error;
        }

        // Close statement
        mysqli_stmt_close($stmt2);
    }

    }


    ?>

<?php include 'inc/footer.php'; ?>