<?php include 'inc/header.php';?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>About Us</title>
    <link rel="stylesheet" href="css/aboutUsStyle.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  </head>
  <body>
    <section class="content">
      <div class="banner-gradient">
        <div class="banner-content">
          <p class="banner-title">PoorBye's History</p>
          <p class="banner-desc">PoorBye is a financial website that was founded in November 2022 by Jasong Dinasty. PoorBye has grown bigger ever since, it has branches are spread all over the world, and now has user from any country!</p>
        </div>
        <div class="aboutus1-banner-image">
          <img src="ASSETS/aboutus/Pemanfaatan Algoritma Support Vector Machine dalam Memprediksi Jantung Koroner.png" alt="" />
        </div>
      </div>
    </section>
    <section class="content">
      <div class="banner-white">
        <div class="aboutus2-banner-image">
          <img src="ASSETS/aboutus/PoorBye AboutUs.png" alt="" />
        </div>
        <div class="banner-content">
          <p class="banner-title">Vision</p>
          <p class="banner-desc">To provide innovative and beneficial solutions to the public for improving skills and financial management.</p>
          <p class="banner-title">Mission</p>
          <p class="banner-desc">To provide high-quality and accurate information and services for skill improvement and financial management.</p>
        </div>
      </div>
    </section>
  </body>
</html>

<?php include 'inc/footer.php';?>