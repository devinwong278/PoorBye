<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>

<?php

extract($_POST);

$idUser = $_SESSION["id"];

$idCourse = $_POST["idCourse"];

$query = mysqli_query($link, "INSERT into `enrollment`(IdCourse, IdUser) values 
($idCourse, $idUser)");


?>