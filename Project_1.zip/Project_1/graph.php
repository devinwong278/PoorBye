<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>



<?php
    $idUser = $_SESSION["id"];

    $bulantahun = $_GET['bulantahun'];
    var_dump($bulantahun);
    
    $graph = mysqli_fetch_all(mysqli_query($link, "SELECT sum(nominal), day(tglTransaksi) 
    from transaksi where idUser = $idUser AND idJenisTransaksi = 1 group by tglTransaksi"), MYSQLI_ASSOC);
    
    $maxY_graph = mysqli_fetch_all(mysqli_query($link, "SELECT max(sn)
    from (SELECT sum(nominal) as sn, day(tglTransaksi) from transaksi where idUser = $idUser AND idJenisTransaksi = 1 group by tglTransaksi) as t"), MYSQLI_ASSOC);
    $maxX_graph = mysqli_fetch_all(mysqli_query($link, 'SELECT max(day(`tglTransaksi`)) from transaksi'), MYSQLI_ASSOC);

$maxY_js = $maxY_graph[0]['max(sn)'];
$maxX_js = $maxX_graph[0]['max(day(`tglTransaksi`))'];

    $count = 0;
    foreach($graph as $item) {

        $yarr[$count] = $item['sum(nominal)'];
        $xarr[$count] = $item['day(tglTransaksi)'];
        $count++;

    }
    $count = 0;

// var_dump($yarr);

?>

<!DOCTYPE html>
<html lang="en-US">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Today's Date</title>
</head>
 
<body>
 
<div id="myPlot" style="width:100%;max-width:700px"></div>


</body>
 
</html>
