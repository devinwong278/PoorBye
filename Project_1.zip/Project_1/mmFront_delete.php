<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>

<?php 

$idUser = $_SESSION["id"];

$idAset = $_GET['idAset'];

$nominal = mysqli_fetch_all(mysqli_query($link, "SELECT nominal
from aset where idUser = $idUser and idAset  =$idAset "), MYSQLI_ASSOC)[0]['nominal'];

// var_dump($idAset);

$sql_update = "UPDATE aset 
set nominal = nominal + $nominal
where idUser = $idUser and namaAset = 'Tabungan'";

$link->query($sql_update);

$sql_delete = "DELETE FROM aset WHERE idUser = $idUser and idAset = $idAset";
$link->query($sql_delete);

// if ($link->query($sql_delete) === TRUE) {
//   echo "Record deleted successfully";
// } else {
//   echo "Error deleting record: " . $link->error;
// }

echo "
    <script>
        alert('data berhasil dihapus');
        document.location.href = 'mmFront.php';
    </script>
";

?>


