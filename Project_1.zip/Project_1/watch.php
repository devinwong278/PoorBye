<?php include 'config/database.php'; ?>

<?php
ob_start();
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;
}

?>

<?php

extract($_POST);

$idUser = $_SESSION["id"];

$idTopic = $_POST["idTopic"];

$query = mysqli_query($link, "INSERT into `watchedTopic`(idUser, idTopic) values 
($idUser, $idTopic)");


?>