<?php include 'inc/header.php'; ?>

<?php
// Initialize the session
// session_start();
 
// Check if the user is logged in, if not then redirect him to login page
// if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
//     header("location: login.php");
//     exit;
// }
// ?>

<?php

$idUser = $namaTarget = $nominalTarget = $tglTarget = $nominalTabung = $frekuensi = "";
$idUser_err = $namaTarget_err = $nominalTarget_err = $tglTarget_err = $nominalTabung_err = $frekuensi_err = "";

// echo $_POST['tglTarget'];

if($_SERVER["REQUEST_METHOD"] == "POST") {

    $idUser = $_SESSION["id"];

    // Check if username is empty
    // if(empty(trim($_POST["namaTarget"]))){
    //     $namaTarget_err = "Please enter target name.";
    // } else{
    //     $namaTarget = trim($_POST["namaTarget"]);
    // }

    // Validate namaTarget
    if(empty(trim($_POST["namaTarget"]))) {
      $namaTarget_err = "Please enter a username.";
    } else {
      // Prepare a select statement
        $sql = "SELECT idTarget FROM targetkeuangan WHERE idUser = $idUser AND namaTarget = ?";
      
        if($stmt = mysqli_prepare($link, $sql)){
          // Bind variables to the prepared statement as parameters
          mysqli_stmt_bind_param($stmt, "s", $param_namaTarget);
          
          // Set parameters
          $param_namaTarget = trim($_POST["namaTarget"]);
          
          // Attempt to execute the prepared statement
          if(mysqli_stmt_execute($stmt)){
              /* store result */
              mysqli_stmt_store_result($stmt);
              
              if(mysqli_stmt_num_rows($stmt) != 0){
                  $namaTarget_err = "Nama target sudah ada.";
              } else{
                  $namaTarget = trim($_POST["namaTarget"]);
              }
          } else{
              echo "Oops! Something went wrong. Please try again later2.";
          }

          // Close statement
          mysqli_stmt_close($stmt);
        }
    }
    
    // Check if nominalTarget is empty
    if(empty(trim($_POST["nominalTarget"]))) {
        $nominalTarget_err = "Please enter your nominalTarget.";
    } else {
        $nominalTarget = trim($_POST["nominalTarget"]);
    }

    if(empty(trim($_POST["tanggal"]))) {
        $tglTarget_err = "Please enter your tglTarget.";
    } else {
        $tglTarget = trim($_POST["tanggal"]);
    }

    if(empty(trim($_POST["harga1"]))) {
        $nominalTabung_err = "Please enter your nominalTabung.";
    } else if (trim($_POST["harga1"]) == -1) {
      $nominalTabung_err = "Invalid Input.";
    } else {
        $nominalTabung = trim($_POST["harga1"]);
    }

    if(empty(trim($_POST["frekuensi"]))) {
        $frekuensi_err = "Please enter your frekuensi.";
    } else {
        $frekuensi = trim($_POST["frekuensi"]);
    }

    
    $arr_frekuensi = mysqli_fetch_all(mysqli_query($link, "SELECT idFrekuensi from frekuensi where jenisFrekuensi = '$frekuensi'"), MYSQLI_ASSOC);
    $idFrekuensi = $arr_frekuensi[0]['idFrekuensi'];

    // var_dump($_POST);
    // var_dump($namaTarget_err);

    if(empty($namaTarget_err) && empty($nominalTabung_err)) {

        $sql = "INSERT INTO targetkeuangan (idUser, idFrekuensi, namaTarget, nominalTarget, tglTarget, tglMulai, nominalTabung) VALUES ($idUser, $idFrekuensi, ?, ?, ?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)) {
        // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sissi", $param_namaTarget, $param_nominalTarget, $param_tglTarget, $param_tglMulai, $param_nominalTabung);
        
        // Set parameters
            $param_namaTarget = $namaTarget;
            $param_nominalTarget = $nominalTarget;
            $param_tglTarget = $tglTarget;
            $param_tglMulai = date("Y-m-d");
            $param_nominalTabung = $nominalTabung;

        
        // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
            // Redirect to login page
                header("location: mmFront.php");
   
            } else{
                echo "Oops! Something went wrong. Please try again later.";
                echo "Error: " . $sql . "<br>" . $link->error;
            }

        // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    

}


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Target</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />
    <link rel="shortcut icon" href="/LOGO.png" type="image/x-icon" />
    <link href="css/targetStyle.css" rel="stylesheet" />
  </head>
  <style>

        .question.active,
        .question2.active {
            display: block;
            /* background-color: black; */
        }
        .question,
        .question2 {
            display: none;
        }


  </style>
  <body>
    <!-- body targetTgl -->
    <div class="signUp">
      <div class="boxluar">
        <div id="judul">Target Baru</div>
        <div class="tentukan">
            Tentukan Targetmu!
        </div>
        <div class="formBox">
            <form action="add_target.php" method="post" id="form">
                <div class="question active">
                    <label class="label1" for="name">Nama Target</label>
                    <span class="output_nama_error" style="color: red;"></span>
                    <input type="text" name="namaTarget" id="name" autocomplete="off" required />
                </div>
                
                <div class="question active">
                    <label class="label1" for="name">Nominal</label>
                    <div class="nominal">
                        <h3>Rp</h3>
                        <input type="text" name="nominalTarget" id="harga" autocomplete="off" required />
                    </div>
                </div>
                <div class="tentukan" id="kapan">
                    Kapan kamu ingin mencapai targetmu?
                </div>
                
                <!-- <div class="active"></div> -->
                
                <div class="tgl">
                    <div class="ijo" id="pilih_tanggal"><p>Pilih Tanggal</p></div>
                    <div class="putih" id="fleksibel"><p>Fleksibel</p></div>
                </div>
                
                <!-- <div class="tgl">
                    <button class="ijo">
                        <p>Pilih Tanggal</p>
                    </button>
                    
                    <button class="putih">
                        <p>Fleksibel</p>
                    </button>
                </div> -->
                
                <!-- <div class="fleksi">
                    <button class="putih">
                        <p>Pilih Tanggal</p>
                    </button>
                    <button class="ijo">
                        <p>Fleksibel</p>
                    </button>
                </div> -->
                
                
                
                <div class="question active" id="tglTarget">
                    <label class="label1" for="name">Pilih Tanggal</label>
                    <input type="date" name="tanggal" id="tanggal" />
                </div>
                
                <div class="question" id="nominalTabung">
                    <label class="label1" for="name">Pilih Nominal Tabung</label>
                    <div class="nominal">
                        <h3>Rp</h3>
                        <input type="text" name="harga1" id="harga1" autocomplete="off" />
                    </div>
                </div>
                
                <div class="versi" id="versitgl">
                    <div class="question2 active">
                        <div class="label1">Frekuensi Tabung</div>
                        <div class="box">
                            <select name="frekuensi" id="selectArea" >
                                <option value="Harian">Harian</option>
                                <option value="Mingguan">Mingguan</option>
                                <option value="Bulanan">Bulanan</option>
                                <option value="Tahunan">Tahunan</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="question2 active" id="est_nominalTabung">
                        <label class="label1" for="name">Nominal Tabung</label>
                        <span class="output_nominal_error" style="color: red;"></span>
                        <div class="nominalHasil" id="nominalHasil">
                            <h3>Rp</h3>
                            <p class="output_nominal"></p>
                        </div>
                    </div>
                    
              <div class="question2" id="est_tanggal">
                <label class="label1" for="name">Tanggal</label>

                  <p class="output_tanggal"></p>  
                  <!-- pake p -->
              </div>
              
            </div>

            <div class="versi" id="versiFlek">
              <!-- <div class="question2">
                <div class="label1">Frekuensi Tabung</div>
                <div class="box">
                  <select name="" id="selectArea" >
                    <option  value="">Harian</option>
                    <option value="">Bulanan</option>
                    <option value="">Tahunan</option>
                  </select>
                </div>
              </div> -->
            </div>

            <div class="submit_container">
              <input type="submit" value="Submit" id="submit">
            </div>

              </form>
            </div>
        </div>
      </div>
    </div>
    <!-- body targetTgl -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

    <script type="text/javascript">

      console.log("mulai")
      // dibawah brikut buat ngasi titik pas nominal dimasukin 
      var rupiah = document.getElementById('harga');
      rupiah.addEventListener('keyup', function(e){
        rupiah.value = formatRupiah(this.value, 'Rp.');
      })

      function formatRupiah(angka, prefix) {
      var num = angka.replace(/[^,\d]/g, '').toString(),
            split = num.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
              sep = sisa ? '.' : '';
              rupiah += sep + ribuan.join('.');
            }

            rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
            return prefix == undefined ? rupiah : rupiah ? rupiah : '';
      }

      var rup = document.getElementById('harga1');
            rup.addEventListener('keyup', function(e){
              rup.value = formatrup(this.value, 'Rp.');
            })
            function formatrup(angka, prefix) {
            var num = angka.replace(/[^,\d]/g, '').toString(),
            split = num.split(','),
            sisa = split[0].length % 3,
            rup = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
              sep = sisa ? '.' : '';
              rup += sep + ribuan.join('.');
            }

            rup = split[1] != undefined ? rup + ',' + split[1] : rup;
            return prefix == undefined ? rup : rup ? rup : '';
      }

      var nom = document.getElementById('harga2');
            // nom.addEventListener('keyup', function(e) {
            // nom.value = formatnom(this.value, 'Rp.');
            // })
            function formatnom(angka, prefix) {
            var num = angka.replace(/[^,\d]/g, '').toString(),
            split = num.split(','),
            sisa = split[0].length % 3,
            nom = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
              sep = sisa ? '.' : '';
              nom += sep + ribuan.join('.');
            }

            nom = split[1] != undefined ? nom + ',' + split[1] : nom;
            return prefix == undefined ? nom : nom ? nom : '';
      }



// backend

// KOLOM NAMA DAN NOMINAL
var namaTarget = document.getElementById('name')
var nominalTarget = document.getElementById('harga')

// tombol PILIH TANGGAL / FLEKSIBEL
var tombol_pilihTgl = document.getElementById('pilih_tanggal')
var tombol_fleksibel = document.getElementById('fleksibel')
// console.log(tombol1)

// KOLOM INPUT TANGGAL ATAU NOMINAL
var input_tglTarget = document.getElementById('tanggal')
var input_nomNabung = document.getElementById('harga1')

// KOTAK INPUT TANGGAL ATAU NOMINAL
var kotak_input_tglTarget = document.getElementById('tglTarget')
var kotak_input_nomNabung = document.getElementById('nominalTabung')

// KOLOM OUTPUT EST_TANGGAL ATAU EST_NOMINAL
var est_tgl = document.getElementById('est_tanggal')
var est_nominalTabung = document.getElementById('est_nominalTabung')

// variable untuk value
var value_tgltarget = input_tglTarget.value
var value_frekuensi
var value_nominalTarget
var value_nominalTarget2

// 
var frekuensi = document.getElementById('selectArea')

kotak_input_tglTarget.onchange = function() {
    value_tgltarget = input_tglTarget.value;
    // console.log("hi"+value_tgltarget);
    // console.log("HALOOO")
}
input_nomNabung.onchange = function() {
    value_nomNabung = input_nomNabung.value;
    value_nomNabung2 = value_nomNabung.split('.').join("");
    value_nomNabung3 = Number(value_nomNabung2);
    input_nomNabung.value = value_nomNabung3;
}

nominalTarget.onchange = function() {
    value_nominalTarget = nominalTarget.value;
    var value_nominalTarget3 = value_nominalTarget.split('.').join("");
    value_nominalTarget2 = Number(value_nominalTarget3);

    nominalTarget.value = value_nominalTarget2;
}

kotak_input_tglTarget.onchange = function() {
  if(tombol_pilihTgl.classList.contains('ijo')) {
    value_tgltarget = input_tglTarget.value;
    console.log("hi"+value_tgltarget);
      var selectElement = document.querySelector('#selectArea');
      console.log(selectElement);
      var value_frekuensi = selectElement.options[selectElement.selectedIndex].value;
      console.log(value_frekuensi);
      var result;
      var today = new Date().toLocaleDateString("en-US");
      var value_tgltarget2 = new Date(value_tgltarget).toLocaleDateString("en-US");
      console.log(value_tgltarget2);
      console.log(today);
      
      var difference = date_diff_indays(today, value_tgltarget2);
      console.log(difference);

      if(value_frekuensi === 'Harian') {
          result = difference;
          console.log(result);
      } else if (value_frekuensi === 'Mingguan') {
          result = Math.floor(difference / 7);
          console.log(result);
      } else if (value_frekuensi === 'Bulanan') {
          result = Math.floor(difference / 30);
          console.log(result);
      } else if (value_frekuensi === 'Tahunan') {
          result = Math.floor(difference / 365);
          console.log(result);
      }

      nominal_per_frekuensi = value_nominalTarget2 / result;
      // console.log(value_nominalTarget);
      console.log(result);
      console.log(nominal_per_frekuensi);

      if(nominal_per_frekuensi != NaN && nominal_per_frekuensi != "Infinity") {
          document.querySelector('.output_nominal').textContent = nominal_per_frekuensi.toFixed(2);
      } else {
        document.querySelector('.output_nominal').textContent = "Invalid";
        nominal_per_frekuensi = -1;
      }

      input_nomNabung.value = nominal_per_frekuensi;
      
      // console.log(document.getElementById('nominalTabung').value);

  }

  if(tombol_fleksibel.classList.contains('ijo')) {
      var selectElement = document.querySelector('#selectArea');
      var value_frekuensi = selectElement.options[selectElement.selectedIndex].value;
      console.log(value_frekuensi);


      var nabungQuantity = value_nominalTarget2 / value_nomNabung3;
      console.log(value_nomNabung);
      console.log(nabungQuantity);

      var result2;


      if(value_frekuensi === 'Harian') {

          result2 = nabungQuantity;

      } else if (value_frekuensi === 'Mingguan') {

          result2 = nabungQuantity * 7;

      } else if (value_frekuensi === 'Bulanan') {

          result2 = nabungQuantity * 30;

      } else if (value_frekuensi === 'Tahunan') {

          result2 = nabungQuantity * 365;

      }



      tanggal_tercapai = new Date();
      tanggal_tercapai.setDate(tanggal_tercapai.getDate() + result2);
      if(tanggal_tercapai != 'NaN') {
          document.querySelector('.output_tanggal').textContent = tanggal_tercapai.toLocaleDateString("en-US");
      }

      // buat ambil 10 character pertama dari tanggal
      input_tglTarget.value = tanggal_tercapai.toISOString().slice(0, 10);

  }
}

kotak_input_nomNabung.onchange = function() {
  if(tombol_pilihTgl.classList.contains('ijo')) {
    value_tgltarget = input_tglTarget.value;
    console.log("hi"+value_tgltarget);
      var selectElement = document.querySelector('#selectArea');
      console.log(selectElement);
      var value_frekuensi = selectElement.options[selectElement.selectedIndex].value;
      console.log(value_frekuensi);
      var result;
      var today = new Date().toLocaleDateString("en-US");
      var value_tgltarget2 = new Date(value_tgltarget).toLocaleDateString("en-US");
      console.log(value_tgltarget2);
      console.log(today);
      
      var difference = date_diff_indays(today, value_tgltarget2);
      console.log(difference);

      if(value_frekuensi === 'Harian') {
          result = difference;
          console.log(result);
      } else if (value_frekuensi === 'Mingguan') {
          result = Math.floor(difference / 7);
          console.log(result);
      } else if (value_frekuensi === 'Bulanan') {
          result = Math.floor(difference / 30);
          console.log(result);
      } else if (value_frekuensi === 'Tahunan') {
          result = Math.floor(difference / 365);
          console.log(result);
      }

      nominal_per_frekuensi = value_nominalTarget2 / result;
      // console.log(value_nominalTarget);
      console.log(result);
      console.log(nominal_per_frekuensi);

      if(nominal_per_frekuensi != NaN && nominal_per_frekuensi != "Infinity") {
          document.querySelector('.output_nominal').textContent = nominal_per_frekuensi.toFixed(2);
      } else {
        document.querySelector('.output_nominal').textContent = "Invalid";
        nominal_per_frekuensi = -1;
      }

      input_nomNabung.value = nominal_per_frekuensi;
      
      // console.log(document.getElementById('nominalTabung').value);

  }

  if(tombol_fleksibel.classList.contains('ijo')) {
      var selectElement = document.querySelector('#selectArea');
      var value_frekuensi = selectElement.options[selectElement.selectedIndex].value;
      console.log(value_frekuensi);


      var nabungQuantity = value_nominalTarget2 / value_nomNabung3;
      console.log(value_nomNabung);
      console.log(nabungQuantity);

      var result2;


      if(value_frekuensi === 'Harian') {

          result2 = nabungQuantity;

      } else if (value_frekuensi === 'Mingguan') {

          result2 = nabungQuantity * 7;

      } else if (value_frekuensi === 'Bulanan') {

          result2 = nabungQuantity * 30;

      } else if (value_frekuensi === 'Tahunan') {

          result2 = nabungQuantity * 365;

      }



      tanggal_tercapai = new Date();
      tanggal_tercapai.setDate(tanggal_tercapai.getDate() + result2);
      if(tanggal_tercapai != 'NaN') {
          document.querySelector('.output_tanggal').textContent = tanggal_tercapai.toLocaleDateString("en-US");
      }

      // buat ambil 10 character pertama dari tanggal
      input_tglTarget.value = tanggal_tercapai.toISOString().slice(0, 10);

  }
}



frekuensi.onchange = function() {
  if(tombol_pilihTgl.classList.contains('ijo')) {
      value_tgltarget = input_tglTarget.value;
      var selectElement = document.querySelector('#selectArea');
      console.log(selectElement);
      var value_frekuensi = selectElement.options[selectElement.selectedIndex].value;
      console.log(value_frekuensi);
      var result;
      var today = new Date().toLocaleDateString("en-US");
      var value_tgltarget2 = new Date(value_tgltarget).toLocaleDateString("en-US");
      console.log(value_tgltarget2);
      console.log(today);
      
      var difference = date_diff_indays(today, value_tgltarget2);
      console.log(difference);

      if(value_frekuensi === 'Harian') {
          result = difference;
          console.log(result);
      } else if (value_frekuensi === 'Mingguan') {
          result = Math.floor(difference / 7);
          console.log(result);
      } else if (value_frekuensi === 'Bulanan') {
          result = Math.floor(difference / 30);
          console.log(result);
      } else if (value_frekuensi === 'Tahunan') {
          result = Math.floor(difference / 365);
          console.log(result);
      }

      nominal_per_frekuensi = value_nominalTarget2 / result;
      // console.log(value_nominalTarget);
      console.log(result);
      console.log(nominal_per_frekuensi);

      if(nominal_per_frekuensi != "NaN" && nominal_per_frekuensi != "Infinity") {
          document.querySelector('.output_nominal').textContent = nominal_per_frekuensi;
      } else {
        document.querySelector('.output_nominal').textContent = "Invalid";
        nominal_per_frekuensi = -1;
      }

      input_nomNabung.value = nominal_per_frekuensi;
      
      // console.log(document.getElementById('nominalTabung').value);

  }

  if(tombol_fleksibel.classList.contains('ijo')) {
      var selectElement = document.querySelector('#selectArea');
      var value_frekuensi = selectElement.options[selectElement.selectedIndex].value;
      console.log(value_frekuensi);


      var nabungQuantity = value_nominalTarget2 / value_nomNabung3;
      console.log(value_nomNabung);
      console.log(nabungQuantity);

      var result2;


      if(value_frekuensi === 'Harian') {

          result2 = nabungQuantity;

      } else if (value_frekuensi === 'Mingguan') {

          result2 = nabungQuantity * 7;

      } else if (value_frekuensi === 'Bulanan') {

          result2 = nabungQuantity * 30;

      } else if (value_frekuensi === 'Tahunan') {

          result2 = nabungQuantity * 365;

      }



      tanggal_tercapai = new Date();
      tanggal_tercapai.setDate(tanggal_tercapai.getDate() + result2);
      if(tanggal_tercapai != 'NaN') {
          document.querySelector('.output_tanggal').textContent = tanggal_tercapai.toLocaleDateString("en-US");
      }

      // buat ambil 10 character pertama dari tanggal
      input_tglTarget.value = tanggal_tercapai.toISOString().slice(0, 10);

  }

};

tombol_pilihTgl.onclick = function() {
    kotak_input_tglTarget.classList.add('active');
    kotak_input_nomNabung.classList.remove('active');
    tombol_fleksibel.classList.add('putih');
    tombol_fleksibel.classList.remove('ijo');
    tombol_pilihTgl.classList.add('ijo');
    tombol_pilihTgl.classList.remove('putih');
    est_nominalTabung.classList.add('active');
    est_tgl.classList.remove('active');
    // console.log("hi");
  }
  
  tombol_fleksibel.onclick = function() {
    kotak_input_tglTarget.classList.remove('active');
    kotak_input_nomNabung.classList.add('active');
    tombol_pilihTgl.classList.add('putih');
    tombol_pilihTgl.classList.remove('ijo');
    tombol_fleksibel.classList.add('ijo');
    tombol_fleksibel.classList.remove('putih');
    est_nominalTabung.classList.remove('active');
    est_tgl.classList.add('active');
    // console.log("hi");
}

var calculate = function() {
  if(tombol_pilihTgl.classList.contains('ijo')) {
      value_tgltarget = input_tglTarget.value;
      var selectElement = document.querySelector('#selectArea');
      console.log(selectElement);
      var value_frekuensi = selectElement.options[selectElement.selectedIndex].value;
      console.log(value_frekuensi);
      var result;
      var today = new Date().toLocaleDateString("en-US");
      var value_tgltarget2 = new Date(value_tgltarget).toLocaleDateString("en-US");
      console.log(value_tgltarget2);
      console.log(today);
      
      var difference = date_diff_indays(today, value_tgltarget2);
      console.log(difference);

      if(value_frekuensi === 'Harian') {
          result = difference;
          console.log(result);
      } else if (value_frekuensi === 'Mingguan') {
          result = Math.floor(difference / 7);
          console.log(result);
      } else if (value_frekuensi === 'Bulanan') {
          result = Math.floor(difference / 30);
          console.log(result);
      } else if (value_frekuensi === 'Tahunan') {
          result = Math.floor(difference / 365);
          console.log(result);
      }

      nominal_per_frekuensi = value_nominalTarget2 / result;
      // console.log(value_nominalTarget);
      console.log(result);
      console.log(nominal_per_frekuensi);

      if(nominal_per_frekuensi != "NaN" && nominal_per_frekuensi != "Infinity") {
          document.querySelector('.output_nominal').textContent = nominal_per_frekuensi;
      } else {
        document.querySelector('.output_nominal').textContent = "Invalid";
        nominal_per_frekuensi = -1;
      }

      input_nomNabung.value = nominal_per_frekuensi;
      
      // console.log(document.getElementById('nominalTabung').value);

  }

  if(tombol_fleksibel.classList.contains('ijo')) {
      var selectElement = document.querySelector('#selectArea');
      var value_frekuensi = selectElement.options[selectElement.selectedIndex].value;
      console.log(value_frekuensi);


      var nabungQuantity = value_nominalTarget2 / value_nomNabung3;
      console.log(value_nomNabung);
      console.log(nabungQuantity);

      var result2;


      if(value_frekuensi === 'Harian') {

          result2 = nabungQuantity;

      } else if (value_frekuensi === 'Mingguan') {

          result2 = nabungQuantity * 7;

      } else if (value_frekuensi === 'Bulanan') {

          result2 = nabungQuantity * 30;

      } else if (value_frekuensi === 'Tahunan') {

          result2 = nabungQuantity * 365;

      }



      tanggal_tercapai = new Date();
      tanggal_tercapai.setDate(tanggal_tercapai.getDate() + result2);
      if(tanggal_tercapai != 'NaN') {
          document.querySelector('.output_tanggal').textContent = tanggal_tercapai.toLocaleDateString("en-US");
      }

      // buat ambil 10 character pertama dari tanggal
      input_tglTarget.value = tanggal_tercapai.toISOString().slice(0, 10);

  }


}

var date_diff_indays = function(date1, date2) {
    dt1 = new Date(date1);
    dt2 = new Date(date2);
    return Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) ) /(1000 * 60 * 60 * 24));
}

var button_submit = document.getElementById('submit');

button_submit.onclick = function() {
  if(document.querySelector('.output_nominal').textContent == "Invalid") {
      document.querySelector('#nominalHasil').focus();
    // alert("Invalid nominal tabung!\nPilih frekuensi lain atau pastikan nominal anda masukkan sudah tepat")
    }
    
    var namaTarget_error = <?php echo json_encode($namaTarget_err) ?>;
    document.querySelector('.output_nama_error').textContent = namaTarget_error;
  
  
}

// to show error message

    </script>
</body>
</html>

<?php include 'inc/footer.php'; ?>