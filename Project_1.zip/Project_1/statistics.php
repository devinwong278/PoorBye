<?php include 'inc/header.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Money Management - PoorBye</title>
    <link rel="stylesheet" href="css/statistics.css">
</head>
<body> 

    <div class="batas">

        <div class="boxjudul">
            <div class="judul">Statistic</div>
        </div>

        <div class="boxpilihan">
            <div class="pemasukan-container">
                <a href="/StatisticPemasukan.html" style="text-decoration: none">Pemasukan</a>
            </div>
            <div class="pengeluaran-container">
                <a href="/StatisticPengeluaran.html" style="text-decoration: none">Pengeluaran</a>
            </div>
        </div>
        
        <div class="boxstatistic">
            <div class="boxpilihanwaktu1">
                <select id="bulantahun">
                    <option value="Tabungan">Juli 2022</option>
                    <option value="Tabungan">Agustus 2022</option>
                </select>
                <select id="range">
                    <option value="Tabungan">Harian</option>
                    <option value="Tabungan">Bulanan</option>
                </select>
            </div> 
            <div class="boxgambarstatistic">
                <!-- <img src="/mixuenigga.jpg" alt="" class="gambarstatistic1"/> -->
                <div id="myPlot" style="width:100%;max-width:700px"></div>
            </div>
            <div class="boxjudulPerbandinganAntara">
                <div class="judulPerbandinganAntara">Perbandingan antara</div>
            </div>
            <div class="boxpilihanwaktu2">
                <select id="bulantahun">
                    <option value="Tabungan">Juli 2022</option>
                    <option value="Tabungan">Agustus 2022</option>
                </select>
                <div class="vs">VS</div>
                <select id="bulantahun">
                    <option value="Tabungan">Juli 2022</option>
                    <option value="Tabungan">Juni 2022</option>
                </select>
            </div> 
            <div class="boxGenerate">
                <div class="generate-container">
                    <a href="/statistics_pemasukan.php" style="text-decoration: none">Generate</a>
                </div>
            </div>

            <div class="boxgambarstatistic2">
                <img src="/mixuenigga.jpg" alt="" class="gambarstatistic2"/>
                <img src="/mixuenigga.jpg" alt="" class="gambarstatistic2"/>

            </div>


        </div>


    </div>
</body>


<?php

        $idUser = $_SESSION["id"];
        $categories = mysqli_fetch_all(mysqli_query($link, "SELECT namaAset from aset where idUser = $idUser"), MYSQLI_ASSOC);
        $count = 0;
        foreach($categories as $item) {
            $category[$count] = $item['namaAset'];
            $count++;
        }
        ?>

<script>

    var category = <?php echo json_encode($category); ?>;

    category.forEach(element => {
        var para2 = document.createElement("option");
            var node2 = document.createTextNode(element);
            para2.appendChild(node2);
            var element2 = document.getElementById("categories");
            element2.appendChild(para2);
        });
        
        </script>

<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>




<script>
     
</script>

<?php
    $idUser = $_SESSION["id"];
    $table_history = mysqli_fetch_all(mysqli_query($link, "SELECT 
    *,
    day(t.tglTransaksi),
    t.nominal
    from transaksi t join aset a on t.idAset = a.idAset
    WHERE t.idJenisTransaksi = 1 AND t.idUser = $idUser
    ORDER BY t.tglTransaksi DESC"), MYSQLI_ASSOC);
    $graph = mysqli_fetch_all(mysqli_query($link, "SELECT sum(nominal), day(tglTransaksi) from transaksi where idUser = $idUser AND idJenisTransaksi = 1 group by tglTransaksi"), MYSQLI_ASSOC);
    $maxY_graph = mysqli_fetch_all(mysqli_query($link, "SELECT max(sn)
    from (SELECT sum(nominal) as sn, day(tglTransaksi) from transaksi where idUser = $idUser AND idJenisTransaksi = 1 group by tglTransaksi) as t"), MYSQLI_ASSOC);
    $maxX_graph = mysqli_fetch_all(mysqli_query($link, 'SELECT max(day(`tglTransaksi`)) from transaksi'), MYSQLI_ASSOC);

$maxY_js = $maxY_graph[0]['max(sn)'];
$maxX_js = $maxX_graph[0]['max(day(`tglTransaksi`))'];

    $count = 0;
    foreach($graph as $item) {

        $yarr[$count] = $item['sum(nominal)'];
        $xarr[$count] = $item['day(tglTransaksi)'];
        $count++;

    }
    $count = 0;

?>

<!-- <?php print_r($table_history); ?> -->




    <script>
    // buat line chart

        var yArray = <?php echo json_encode($yarr); ?>;
        var xArray = <?php echo json_encode($xarr); ?>;
        var maxY = <?php echo json_encode($maxY_js) ?>;
        var maxX = <?php echo json_encode($maxX_js) ?>;
        
        // Define Data
        var data = [{
            x: xArray,
            y: yArray,
            type: "bar",
            line: {
                color: 'rgb(90, 210, 102)',
                width: 5
            }
        }];

        // Define Layout
        var layout = {
            xaxis: {range: [0, maxX], title: "Date"},
            yaxis: {range: [0, maxY], title: "Nominal"},  
            title: "November 2022"
        };

        // Display using Plotly
        Plotly.newPlot("myPlot", data, layout);
        
        var data2 = [{
            x: xArray,
            y: yArray,
            type: "line",
            line: {
                color: 'rgb(90, 210, 102)',
                width: 5
            }
        }];

        // Define Layout
        var layout2 = {
            xaxis: {range: [0, maxX], title: "Date"},
            yaxis: {range: [0, maxY], title: "Nominal"},  
            title: "November 2022"
        };

        // Display using Plotly
        Plotly.newPlot("myPlot", data2, layout2);

        
    </script>


</html>




<?php include 'inc/footer.php'; ?>